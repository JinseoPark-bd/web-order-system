<style scoped lang="scss">
    .col-md-12{
      padding:12px 0;
    }
    .col-12{
      padding:12px 0;
    }
  .regist-popup{
    >.ui-row{
      padding:0;
      margin:0;
    }
    .ui-col{
      padding:12px 0;
    }
    
  }
</style>
<template>
  <div class="regist-popup">
    <v-row class="ui-row">
      
      <v-col
        cols="12"
        md="12"
        class="ui-col"
      >
          <div class="data-control">
            <button type="button" class="search-btn" @click="deleteItems()" style="margin-left:0">
              
            <svg xmlns="http://www.w3.org/2000/svg" height="18" viewBox="0 -960 960 960" width="18" fill="#ffffff"><path d="M280-120q-33 0-56.5-23.5T200-200v-520h-40v-80h200v-40h240v40h200v80h-40v520q0 33-23.5 56.5T680-120H280Zm400-600H280v520h400v-520ZM360-280h80v-360h-80v360Zm160 0h80v-360h-80v360ZM280-720v520-520Z"/></svg>
                삭제
            </button>
            
            <button type="button" class="search-btn" @click="validItems()">
              <svg xmlns="http://www.w3.org/2000/svg" height="18" viewBox="0 -960 960 960" width="18" fill="#ffffff"><path d="M480-80q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q65 0 123 19t107 53l-58 59q-38-24-81-37.5T480-800q-133 0-226.5 93.5T160-480q0 133 93.5 226.5T480-160q133 0 226.5-93.5T800-480q0-18-2-36t-6-35l65-65q11 32 17 66t6 70q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Zm-56-216L254-466l56-56 114 114 400-401 56 56-456 457Z"/></svg>
                검증
            </button>
            <button type="button" class="search-btn" @click="addItems()" >
              <svg xmlns="http://www.w3.org/2000/svg" width="18px" height="18px" fill="#ffffff" viewBox="0 0 24 24"><path d="M12.35 20H10V17H12.09C12.21 16.28 12.46 15.61 12.81 15H10V12H14V13.54C14.58 13 15.25 12.61 16 12.35V12H20V12.35C20.75 12.61 21.42 13 22 13.54V5C22 3.9 21.1 3 20 3H4C2.9 3 2 3.9 2 5V20C2 21.1 2.9 22 4 22H13.54C13 21.42 12.61 20.75 12.35 20M16 7H20V10H16V7M10 7H14V10H10V7M8 20H4V17H8V20M8 15H4V12H8V15M8 10H4V7H8V10M17 14H19V17H22V19H19V22H17V19H14V17H17V14" /></svg>
              제품추가
            </button>
          </div>
      </v-col>
      <v-col
          cols="12"
          md="12"
          class="ui-col"
      >
          <div id="upload-pop-modal" class="real-grid"></div>  
      </v-col>
    </v-row>
  </div>
</template>

<script>
import { GridView, LocalDataProvider } from 'realgrid'
import { uploadFields, uploadColumns } from '../views/gridData/CommonUploadPopup.js'
import { mapGetters } from 'vuex'

let gridView = GridView
let localDataProvider = LocalDataProvider

export default {
  name: 'CommonUploadPopup',
  props : {
    selectRegistEvent : Function,
    ordPropObj: Object
  },
  data() {
    return {
      itemList: [],
      validItem: [],
      failCount: 0,
      registInput: '',
      registNmInput: '',
      registCdInput: ''
    }
  },
  methods: {
    getAvailableItems() {

        this.$loading.show({delay:0})
        this.$store.dispatch('apiOrdItemInfo', this.ordPropObj).then(() => {
          
          if(this.itemPopObj.code === 'SUCCESS') {
            //console.log(this.getOrdItemInfo)
            this.itemList = []
            for(var i=0; i < this.itemPopObj.itemInfo.length; i++ ){
              if(this.itemPopObj.itemInfo[i].contractYn === 'Y'){
                var item = this.itemPopObj.itemInfo[i]
                this.itemList.push(item)
              }
            }
            // localDataProvider.setRows(this.registList)
            //console.log(this.itemList)
          } else {
            this.$swal({
              title: this.itemPopObj.message
            })
          }
        }).catch((error) => {
          // console.log(error)
          this.$swal({
            title: error
          })
        }).finally(() => {
          setTimeout(() => {
            this.$loadingHide()
          }, 300);
        })
    },
    addItems(){
      this.validItems()

      if(this.failCount !== 0){
        this.$swal({
          title: '검증이 통과되지 않은 라인이 존재합니다.'
        })
        return
      }
      
      var items = localDataProvider.getJsonRows()

      if(items.length === 0){
        this.$swal({
            title: '입력한 제품이 없습니다.'
        })

        var curRows = localDataProvider.getJsonRows()
        if (curRows.length === 0) {
          localDataProvider.clearRows()
          gridView.beginAppendRow()
          gridView.showEditor()
          gridView.setFocus()
        }
        return
      }

      var itemArray = []
      for(var i=0; i<items.length; i++){
        var item = items[i]
        var index = this.itemList.findIndex(i => i.itemCd == item.itemCd)

        var tmpItem = this.itemList[index]
        tmpItem.ordQty = item.qty

        itemArray.push(tmpItem)
      }
      // console.log(itemArray)
      this.$emit('selectRegistEvent', itemArray)

    },
    deleteItems(){

      var items = gridView.getCheckedRows()

      if (items.length === 0) {
        this.$swal({
          title: '삭제 할 데이터가 존재하지 않습니다'
        })
        
        return
      }

      gridView.cancel()
      localDataProvider.removeRows(items)
      var curRows = localDataProvider.getJsonRows()
      if (curRows.length === 0) {
        localDataProvider.clearRows()
        gridView.beginAppendRow()
        gridView.showEditor()
        gridView.setFocus()
      }

    },
    validItems(){
      gridView.cancel()

      if(this.itemList.length === 0){
        this.$swal({
            title: '거래처의 등록할 수 있는 제품이 없습니다.'
        })
        return
      }

      var gridRows = localDataProvider.getJsonRows()

      if(gridRows.length === 0){
        this.$swal({
            title: '입력한 제품이 없습니다.'
        })
        return
      }
      
      this.validItem = []
      this.failCount = 0
      for(var i=0; i<gridRows.length; i++){
        var item = gridRows[i]
        
        item.validYn = 'Y'
        item.validMsg = '정상'

        if(item.itemCd === '' || item.itemCd === undefined){
          item.validYn = 'N'
          item.validMsg = '제품코드X'
          this.failCount++
        }

        if(item.qty === '' || item.qty === undefined || item.qty <= 0){
          item.validYn = 'N'
          item.validMsg = '제품수량X'
          this.failCount++
        }

        var index = this.itemList.findIndex(i => i.itemCd == item.itemCd)
        if(item.validYn === 'Y'){
          if(index === -1){
            item.validYn = 'N'
            item.validMsg = '입력할 수 없는 제품'
            this.failCount++
          }
        }

        var duplIndex = this.validItem.findIndex(i => i.itemCd == item.itemCd)

        if(item.validYn === 'Y'){
          if(duplIndex !== -1){
            item.validYn = 'N'
            item.validMsg = '이미 등록한 제품'
            this.failCount++
          }
        }

        this.validItem.push(item)
      }

      //gridView.cancel()
      //gridView.refresh()
     
      localDataProvider.setRows(this.validItem)
      gridView.refresh()

      //console.log('=============== console.log(this.validItem)')
      //console.log(this.validItem)

    }
  },
  mounted() {
    // this.startOZViewer()
    
    localDataProvider = new LocalDataProvider(false)
    gridView = new GridView('upload-pop-modal')
    gridView.setDataSource(localDataProvider)
    
    gridView.undoable = true
    gridView.redoable = true
    gridView.setCheckBar({
      visible: true
    })
    gridView.setStateBar({
      visible: false
    })
    gridView.setPasteOptions({
      enabled: true,
      enableAppend: true
    })
    gridView.setEditOptions({
      insertable: true,
      appendable: true,
      appendWhenExitLast: true,
      commitByCell: true,
      commitWhenExitLast: true,
      commitWhenLeave: true,
      deletable: true
      
    })


    localDataProvider.setFields(uploadFields)
    gridView.setColumns(uploadColumns)

    gridView.displayOptions.selectionStyle = "singleRow"
    gridView.displayOptions.fitStyle = "even"

    gridView.cancel()
    localDataProvider.clearRows()
    gridView.beginAppendRow()
    gridView.showEditor()
    gridView.setFocus()
    gridView.onFiltering = function (grid){
        grid.cancel()
        grid.cancelEditor()
        grid.clearCurrent()
    }  

    this.getAvailableItems()
  },
  computed: {
    ...mapGetters({
      itemPopObj: 'getOrdItemInfo'
    })
  },
}
</script>