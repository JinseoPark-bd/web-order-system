<template>
  <div class="home">
    <v-row class="ui-row">
      <v-col
        cols="12"
        md="12"
        class="d-flex flex-row"
      >
      <h2 class="content-tit">오늘의 주문, 배송 현황</h2>
      </v-col>
      <v-col
        cols="12"
        md="12"
        class="ui-col"
      >
        <ul class="current-list" :class="[ownerKey === 'A08462' ? 'jnj' : 'standard']">
          <li class="list-item" data-hidden="mobile" v-if="ownerKey === 'A08462'">
            <p class="label">재고확인</p>
            <p class="tit">버튼 클릭 시,<br>렌즈 재고유무를 <br>확인할 수 있습니다.</p>
            <button type="button" class="button search-btn print" @click="printStockList()">
              <svg xmlns="http://www.w3.org/2000/svg" height="18" viewBox="0 96 960 960" width="18" fill="#ffffff"><path d="M350 566q-12.75 0-21.375-8.675-8.625-8.676-8.625-21.5 0-12.825 8.625-21.325T350 506h260q12.75 0 21.375 8.675 8.625 8.676 8.625 21.5 0 12.825-8.625 21.325T610 566H350Zm0-160q-12.75 0-21.375-8.675-8.625-8.676-8.625-21.5 0-12.825 8.625-21.325T350 346h260q12.75 0 21.375 8.675 8.625 8.676 8.625 21.5 0 12.825-8.625 21.325T610 406H350ZM220 666h320q26.43 0 49.215 12Q612 690 628 710l112 146V236H220v430Zm0 250h490L581 747q-7.565-9.882-18.283-15.441Q552 726 540 726H220v190Zm520 60H220q-24 0-42-18t-18-42V236q0-24 18-42t42-18h520q24 0 42 18t18 42v680q0 24-18 42t-42 18Zm-520-60V236v680Zm0-190v-60 60Z"/></svg>
              재고표
            </button>
          </li>
          <li class="list-item">
            <p class="label">주문</p>
            <p class="tit" data-hidden="mobile">병원 직원 또는 병원담당 CIS가 <br>주문할 제품을 저장</p>
            <p class="number">
              <strong class="qty">{{this.dashInfo.ordQty}}</strong>건
            </p>
            <i class="icon 01">
              <img src="../img/main-banner-icon01.png" alt="주문">
            </i>
          </li>
          <li class="list-item">
            <p class="label">접수</p>
            <p class="tit" data-hidden="mobile">병원담당 CIS 또는 영업사원이 <br>주문을 확인</p>
            <p class="number">
              <strong class="qty">{{this.dashInfo.recQty}}</strong>건
            </p>
            <i class="icon 02">
              <img src="../img/main-banner-icon02.png" alt="접수">
            </i>
          </li>
          <li class="list-item">
            <p class="label">확정</p>
            <p class="tit" data-hidden="mobile">병원담당 CIS 또는 영업사원이 <br>주문을 창고 담당자에게 전달</p>
            <p class="number">
              <strong class="qty">{{this.dashInfo.confirmQty}}</strong>건
            </p>
            <i class="icon 03">
              <img src="../img/main-banner-icon03.png" alt="확정">
            </i>
          </li>
          <li class="list-item">
            <p class="label">배송</p>
            <p class="tit" data-hidden="mobile">병원담당 CIS가 주문한 제품을 <br>병원 직원에게 전달</p>
            <p class="number">
              <strong class="qty">{{this.dashInfo.divQty}}</strong>건
            </p>
            <i class="icon 04">
              <img src="../img/main-banner-icon04.png" alt="배송">
            </i>
          </li>
        </ul>
      </v-col>
      <v-col
        cols="12"
        md="12"
        class="ui-col"
      >
      <div class="visual-bottom">
          <div class="notice-area">
            <div class="header">
              <h3 class="main-tit">공지사항</h3>
              <button type="button" class="view-add" @click="noticeSearcheList()">
                  <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="#000000"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>
                </button>
            </div>
            <div class="desc">
              <ul class="notice-list">
                <li class="list-item" v-for="(item, index) in noticeList.slice(0,5)" :key="index">
                  <button type="button" class="notice-btn" @click="callNoticeContent(item)">
                    <span class="tit">{{item.msgTitle | truncate(35, '...')}}</span>
                    <span class="date">{{item.msgStartDt | truncate(10, ' ')}}</span>
                  </button>
                </li>
              </ul>
            </div>
          </div>
          <div class="customer-service">
              <h3 class="banner-tit">고객센터</h3>
              <!-- <h3 class="banner-tit"><strong>{{ userInfo.ownerNm }}</strong>고객센터</h3> -->
              <p class="banner-txt">문의주신 내용에 대해 정성껏 답변 드리겠습니다.</p>
              <p class="banner-txt"><span class="dt">전화번호: </span>{{ userInfo.ownerTel }}</p>
              <p class="banner-txt"><span class="dt">이메일: </span>{{ userInfo.ownerEmail }}</p>
          </div>
        </div>
      </v-col>
    </v-row>
    <div data-app>
      <v-dialog
        v-model="dialog"
        persistent
        max-width="800px"
        id="user-info-modal"
      >
        <v-card>
          <v-card-title>
            <v-col 
            cols="12"
            md="12">
              <span class="text-h5">{{notiTitle}}</span>
            </v-col>
          </v-card-title>
          <v-card-text>
            <v-container>
              <v-row>
                <v-col 
                  cols="12"
                  md="12">
                  <div class="notice-popup-desc" v-html="notiContent">
                  </div>
                  </v-col>
                  <v-col 
                  cols="12"
                  md="10">
                <span>
                  <p>작성자 : {{notiCreator}}</p>
                </span>
                  </v-col>
                  <v-col 
                  cols="12"
                  class="text-end"
                  md="2">
                    {{notiCreatDt}}
                  </v-col>
                  <v-col
                  cols="12"
                  md="12"
                  class="text-end"
                >
                  <v-btn
                    color="blue darken-1"
                    class="default-btn-style"
                    text
                    @click="dialog = false"
                  >
                    닫기
                  </v-btn>
                </v-col>
              </v-row>
            </v-container>
          </v-card-text>
        </v-card>
      </v-dialog>
    </div>
    <div data-app>
      <v-dialog
        v-model="noticeDialog"
        persistent
        max-width="1200px"
        id="user-info-modal"
      >
        <v-card>
          <v-card-title>
            <span class="text-h5">{{noticeCardTitle}}</span>
          </v-card-title>
          <v-card-text>
            <v-container>
              <v-row>
                <v-col
                  cols="12"
                  md="12"
                >
                  <div id="home-notice-modal" class="real-grid"></div>
                </v-col>
                <v-col
                  cols="12"
                  md="12"
                  class="text-end"
                >
                  <v-btn
                    color="blue darken-1"
                    class="default-btn-style"
                    text
                    @click="noticeDialog = false"
                  >
                    닫기
                  </v-btn>
                </v-col>
              </v-row>
            </v-container>
            <!--<small>*indicates required field</small>-->
          </v-card-text>
        </v-card>
      </v-dialog>
    </div>
    <div report-app>
      <v-dialog
        v-model="printDialog"
        persistent
        id="report-info-modal"
        content-class="report-modal"
      >
        <v-card class="report-card">
          <v-card-title>
            <span class="text-h5">{{cardTitle}}</span>
          </v-card-title>
          <v-card-text>
            <v-container>
              <v-row>
                <v-col
                  cols="12"
                  md="12"
                >
                  <!--<div id="ozviewer" class="ozviewer">
                    <OZViewer></OZViewer>
                  </div>-->
                  <OZViewer ref="ozViewerRef" v-if="printDialog"></OZViewer>
                </v-col>
              </v-row>
            </v-container>
            <!--<small>*indicates required field</small>-->
          </v-card-text>
          <v-card-actions>
            <v-spacer>
            </v-spacer>
            <v-btn
              color="blue darken-1"
              text
              @click="printDialog = false"
            >
              닫기
            </v-btn>
          </v-card-actions>
        </v-card>
      </v-dialog>
    </div>
    <div data-app>
      <v-dialog
        v-model="personInformDialog"
        persistent
        max-width="800px"
        content-class="pl-container"
        id="person-info-modal"
      >
        <v-card>
          <v-card-title>
            <span class="text-h5">개인정보처리방침 변경 안내</span>
          </v-card-title>
          <v-card-text>
            <v-container>
              <v-row>
                <v-col
                  cols="12"
                  md="12"
                >
                  <p class="default-txt">
                    개인정보처리방침이 다음과 같이 개정되어 변경 내용을 사전 공지하오니, 서비스 이용에 참조하시기 바랍니다.
                  </p>
                  <p class="default-txt"><span class="bold">변경사유</span></p>
                  <p class="default-txt">개인정보 보호책임자 변경 및 개인정보 처리목적 수정</p>
                  <p class="default-txt"><span class="bold">변경일자</span></p>
                  <p class="default-txt">2023-09-23(토)</p>
                  <p class="default-txt"><span class="bold">변경내용</span></p>
                  <p class="default-txt">
                    - 개인정보 보호책임자 변경 : 김상권 ▶ 성종현<br>
                    - 개인정보 처리목적 내용 추가: 개인식별정보, 제한적 본인 식별정보
                  </p>
                  <p class="default-txt" style="margin-bottom:0;">관련하여 궁금하신 사항이나 소중한 의견은 언제든지 고객센터로 알려주시면 안내해 드리도록 하겠습니다. 감사합니다.</p>
                </v-col>
                <v-col
                  cols="12"
                  md="12"
                  class="ui-col"
                  style="padding:0 12px"
                >
                  <v-checkbox color="primary"
                  v-model="rememberOption"
                  label="일주일간 보지 않음">
                  </v-checkbox>
                </v-col>
                <v-col
                  cols="12"
                  md="12"
                  class="ui-col text-center"
                >
                  <v-btn
                    color="blue darken-1"
                    class="default-btn-style"
                    @click="saveAndClosePopup"
                    text
                  >
                    확인
                  </v-btn>
                  <v-btn
                    color="blue darken-1"
                    class="close-btn-style"
                    style="margin-left:10px"
                    text
                    @click="personInformDialog = false"
                  >
                    취소
                  </v-btn>
                </v-col>
              </v-row>
            </v-container>
            <!--<small>*indicates required field</small>-->
          </v-card-text>
        </v-card>
      </v-dialog>
    </div>
  </div>
</template>

<script>

import { mapGetters } from 'vuex'
import { GridView, LocalDataProvider } from 'realgrid'
import { noticeFields, noticeColumns } from './gridData/HomeNotice.js'
import dayjs from 'dayjs'
import VueCookies from "vue-cookies"
let noticeGridView = GridView
let noticeDataProvider = LocalDataProvider
export default {
  name: 'Home',
  component: {
    dayjs
  },
  data() {
    return {
      ownerKey: '',
      userId: '',
      agentCd: '',
      noticeList: [],
      noticeDialog: false,
      notiTitle: 'noti',
      notiContent: 'Content',
      notiCreator: '생성자',
      notiCreatDt: '',
      dialog: false,
      cardTitle: '거래처별 재고 정보',
      noticeCardTitle: '공지사항',
      initNoticeFlag: false,
      today: dayjs().format("YYYY-MM-DD"),
      // 추후 변화 필요함
      ownerList: [],
      agentList: [],
      dashInfo : '',
      userInfo: {
        ownerNm: '',
        ownerTel: '',
        ownerEmail: ''
      },
      printDialog: false,
      custList: [],
      duplicateFlag: true,
      strAgentCd: '',
      personInformDialog: false,
      rememberOption:false
    }
  },
  created() {
    var info = JSON.parse(sessionStorage.getItem('userInfo'))
    
    var selectOwner = sessionStorage.getItem('selectOwner')

    //console.log('info정보' + JSON.stringify(info))
    const savedRememberOption = VueCookies.get("rememberOption");
    if (savedRememberOption === 'true') {
      this.rememberOption = true;
    }
    for(var i=0; i<info.length; i++){
      if(info[i].ownerKey === selectOwner){
        this.ownerKey = info[i].ownerKey
        this.userId = info[i].userId
        this.agentCd = info[i].agentCd
        this.userInfo.ownerNm = info[i].ownerNm
        this.userInfo.ownerTel = info[i].ownerTel
        this.userInfo.ownerEmail = info[i].ownerEmail
        break
      }
    }
    if(this.ownerKey === 'A08462' && savedRememberOption != 'true'){
      this.personInformDialog = true
    }
    //console.log('this.ownerKey = ' + this.ownerKey)
    //console.log('this.userId = ' + this.userId)
    //console.log('this.agentCd = ' + this.agentCd)


  },
  mounted() {
    this.callNoticeList()
    // this.getDashboardData() 세션체크
    this.callDashInfo()

    
  },
  methods: {
    saveAndClosePopup() {
        // 설정을 쿠키에 저장 (7일간 유지)
        VueCookies.set("rememberOption", this.rememberOption, "7d")
        this.personInformDialog = false
      },
    callDashInfo(){
      this.$loading.show({delay:0})
        this.$store.dispatch('apiDashInfo',{ 'ownerKey' :this.ownerKey, 'userId' : this.userId}).then(() => {
        if(this.dashInfoObj.code === 'SUCCESS') {
          //console.log('this.dashInfoObj')
          this.dashInfo = this.dashInfoObj.dashInfo
          //console.log(this.dashInfoObj)
        } else {
          this.$swal({
            title: 'DashBoard 호출에 실패하였습니다.'
          })
        }
      }).catch((error) => {
        this.$swal({
          title: 'ErrorCode = ' + error.response.status + ' / ' + error.message + '\n시스템에 이상이 있습니다. 다시 검색해 주세요.'
        })
      }).finally(() => {
        setTimeout(() => {
          this.$loadingHide()
        }, 300)
      })
    },
    callNoticeList () {
      this.$loading.show({delay:0})
        this.$store.dispatch('apiNoticeData',{ 'ownerKey' :this.ownerKey, 'userId' : this.userId}).then(() => {
          if(this.noticeRowObj.code === 'SUCCESS') {
          this.noticeList = []
          this.noticeRow = this.noticeRowObj.noticeInfo
          for (var i=0; i<this.noticeRow.length; i++){
            var obj = this.noticeRow[i]
            this.noticeRow[i].msgStartDt = dayjs(this.noticeRow[i].msgStartDt).format("YYYY-MM-DD")
            this.noticeList.push(obj)
          }
        }
      }).catch((error) => {
        this.$swal({
          title: 'ErrorCode = ' + error.response.status + ' / ' + error.message + '\n시스템에 이상이 있습니다. 다시 검색해 주세요.'
        })
      }).finally(() => {
        setTimeout(() => {
          this.$loadingHide()
        }, 300)
      })
    },
    callNoticeContent(obj) {
      this.$loading.show({delay:0})
      this.$store.dispatch('apiNoticeContent', {msgNo: obj.msgNo}).then(() => {
        if(this.noticeContentObj.code === 'SUCCESS') {
          obj.noticeContent = this.noticeContentObj.noticeDtl.msgContent
          this.noticeDialog = false
          this.noticeClick(obj)
          // console.log(obj)
        } else {
          this.$swal({
            title: '공지 사항 내용 호출에 실패하였습니다.'
          })
        }
      }).catch((error) => {
        this.$swal({
          title: 'ErrorCode = ' + error.response.status + ' / ' + error.message + '\n시스템에 이상이 있습니다. 다시 검색해 주세요.'
        })
      }).finally(() => {
        setTimeout(() => {
          this.$loadingHide()
        }, 300)
      })
    },
    noticeClick(obj) {
      this.dialog = true
      this.notiTitle = obj.msgTitle
      this.notiContent = obj.noticeContent
      this.notiCreator = obj.msgCreator
      this.notiCreatDt = obj.msgStartDt.split(' ')[0]
    },
    noticeSearcheList() {
      var tmpThis = this
      this.noticeDialog = true
      setTimeout(() => {
        if(this.initNoticeFlag === false){
          this.initNoticeFlag = true
          noticeDataProvider = new LocalDataProvider(true)
          noticeGridView = new GridView('home-notice-modal')
          noticeGridView.setDataSource(noticeDataProvider)
          noticeDataProvider.setFields(noticeFields)
          noticeGridView.setColumns(noticeColumns)
        }
        noticeGridView.setCheckBar({
          visible: false
        })
        noticeGridView.setStateBar({
          visible: false
        })
        noticeDataProvider.setRows(tmpThis.noticeRow)
        noticeGridView.displayOptions.fitStyle = "even"
        noticeGridView.onCellDblClicked = function (grid, clickData) {
          if(clickData.cellType !== 'header' && clickData.cellType !== 'head'){
            var idx = clickData.dataRow
            var curObj = noticeDataProvider.getJsonRow(idx)
            // console.log('curObj = ' + JSON.stringify(curObj))
            tmpThis.callNoticeContent(curObj)
          }
        }
      }, 300);
    },
    printStockList() {
      // 오즈 리포트 실행
      if(this.agentCount === 0){
        this.$swal({
            title: '아직 데이터를 불러오지 못했습니다. 잠시 후 다시 클릭해주세요.'
        })
        // alert('아직 데이터를 불러오지 못했습니다. 잠시 후 다시 클릭해주세요.')
        return
      }

      if(this.agentCount > 1){
        this.$swal({
            title: '현재 사용자 계정은 재고표를 출력할 수 없습니다. 거래처별 재고조회에서 확인해주세요.'
        })
        return
      }

      this.strAgentCd = this.custInfoObj[0].agentCd

      this.printDialog = true
      var fileNames = [
        'CIMS_Confirmation_Outside',
        'CIMS_Confirmation_Outside2',
        'CIMS_Confirmation_Outside3',
        'CIMS_Confirmation_Outside6'
      ]
      var argsArray = [
        {'owKey': this.ownerKey, 'agKey': this.strAgentCd},
        {'owKey': this.ownerKey, 'agKey': this.strAgentCd},
        {'owKey': this.ownerKey, 'agKey': this.strAgentCd},
        {'owKey': this.ownerKey, 'agKey': this.strAgentCd}
      ]
      var paramData = this.$getOzViewData(fileNames, argsArray)
      setTimeout(() => {
        this.$refs.ozViewerRef.initOzExecution(paramData)
      }, 500)      
    }
  },
  computed: {
    ...mapGetters({
      noticeRowObj: 'getNoticeData',
      noticeContentObj: 'getNoticeContent',
      dashInfoObj: 'getDashInfo',
      custInfoObj: 'getCustMstData',
      agentCount: 'getAgentCount'
      // totalInfoObj: 'getTotalData',
      // codeInfoObj: 'getCodeData',
      // ordCustCodeObj: 'getOrdCodeData'
    })
  }
}
</script>
