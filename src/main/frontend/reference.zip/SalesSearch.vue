<template>
  <div class="real-container">
    <v-row class="ui-row">
      <v-col
        cols="12"
        md="12"
        class="d-flex flex-row"
      >
        <h2 class="content-tit">
            {{pageTitle}}
        </h2>
        <div class="data-control">
          <button type="button" class="button search-btn" @click="searchBackOrderInfo()">
            <svg xmlns="http://www.w3.org/2000/svg" height="18px" viewBox="0 0 24 24" width="18px" fill="#ffffff"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/></svg>
            검색
          </button>
          <button type="button" class="button data-excel" @click="exportExcel()">
            <svg xmlns="http://www.w3.org/2000/svg" height="18px" viewBox="0 0 24 24" width="18px" fill="#fff"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z"/><path d="M7.646 11.854a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V1.5a.5.5 0 0 0-1 0v8.793L5.354 8.146a.5.5 0 1 0-.708.708l3 3z"/></svg>
            엑셀다운
          </button>
          <button type="button" class="button search-btn print" @click="printStockList()" data-hidden="mobile">
            <svg xmlns="http://www.w3.org/2000/svg" height="18" viewBox="0 96 960 960" width="18" fill="#ffffff"><path d="M350 566q-12.75 0-21.375-8.675-8.625-8.676-8.625-21.5 0-12.825 8.625-21.325T350 506h260q12.75 0 21.375 8.675 8.625 8.676 8.625 21.5 0 12.825-8.625 21.325T610 566H350Zm0-160q-12.75 0-21.375-8.675-8.625-8.676-8.625-21.5 0-12.825 8.625-21.325T350 346h260q12.75 0 21.375 8.675 8.625 8.676 8.625 21.5 0 12.825-8.625 21.325T610 406H350ZM220 666h320q26.43 0 49.215 12Q612 690 628 710l112 146V236H220v430Zm0 250h490L581 747q-7.565-9.882-18.283-15.441Q552 726 540 726H220v190Zm520 60H220q-24 0-42-18t-18-42V236q0-24 18-42t42-18h520q24 0 42 18t18 42v680q0 24-18 42t-42 18Zm-520-60V236v680Zm0-190v-60 60Z"/></svg>
            거래명세서
          </button>
        </div>
      </v-col>
      <v-col
        cols="12"
        md="6"
        lg="4"
        class="ui-col client-ui"
      >
      <label class="default-tit input-tit text-center" for="client-tit">
          거래처 
        </label>
        <div class="client-box">
          <input type="text"
            class="default-input client-input left"
            @click="clientFlag = true"
            id="client-tit"
            v-model="strCustCd"
            :disabled="custList.length <= 1"
          />
          <button type="button"
            @click="clientFlag = true"
            v-if="custList.length > 1"
            class="client-search-btn">
            <svg xmlns="http://www.w3.org/2000/svg" class="search-icon" height="24px" viewBox="0 0 24 24" width="24px" fill="#000000">
              <path d="M0 0h24v24H0z" fill="none"/>
              <path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/>
            </svg>
          </button>
          <input type="text" class="default-input client-input right" id="client-right" v-model="strCustNm" disabled/>
        </div>
      </v-col>
      <v-col
        cols="12"
        md="6"
        lg="4"
        class="ui-col"
      >
      <label class="default-tit input-tit text-center" for="occurrence-start">
          주문일 
        </label>
        <div class="date-container half">
          <div class="datepicker-aligns">
            <v-menu
              v-model="dateFromMain"
              :close-on-content-click="false"
              :nudge-left="0"
              transition="scale-transition"
              offset-y
              min-width="auto"
            >
              <template v-slot:activator="{ on, attrs }">
                <v-text-field
                  v-model="occurrenceFromMain"
                  prepend-icon="mdi-calendar"      
                  label="From"
                  readonly
                  v-bind="attrs"
                  v-on="on"
                ></v-text-field>
              </template>
              <v-date-picker
                v-model="occurrenceFromMain"
                locale="ko"
                @input="dateFromMain = false"
              ></v-date-picker>
            </v-menu>
          </div>
        </div>
        <div class="date-container half">
          <div class="datepicker-aligns">
            <v-menu
              v-model="dateToMain"
              :close-on-content-click="false"
              :nudge-left="0"
              transition="scale-transition"
              offset-y
              min-width="auto"
            >
              <template v-slot:activator="{ on, attrs }">
                <v-text-field
                  v-model="occurrenceToMain"
                  prepend-icon="mdi-calendar"      
                  label="To"
                  readonly
                  v-bind="attrs"
                  v-on="on"
                ></v-text-field>
              </template>
              <v-date-picker
                v-model="occurrenceToMain"
                locale="ko"
                @input="dateToMain = false"
              ></v-date-picker>
            </v-menu>
          </div>
        </div>
      </v-col>
    </v-row>
    <v-row class="ui-row">
      <v-col
        cols="12"
        md="12"
        class="ui-col d-flex flex-column"
      >
          <h3 class="grid-tit">{{cardTitle}}</h3>
          <!--<div id="master-left-data" class="real-grid"></div>-->
          <div id="master-grid" class="real-grid"></div>
      </v-col>
    </v-row>

    <div report-app class="report-modal">
      <v-dialog
        v-model="printDialog"
        persistent
        id="report-modal"
        content-class="report-modal"
      >
        <v-card class="report-card">
          <v-card-title>
            <span class="text-h5">{{cardTitle}}</span>
          </v-card-title>
          <v-card-text>
            <v-container>
              <v-row>
                <v-col
                  cols="12"
                  md="12"
                >
                  <!--<div id="ozviewer" class="ozviewer">
                    <OZViewer></OZViewer>
                  </div>-->
                  <OZViewer ref="ozViewerRef" v-if="printDialog"></OZViewer>
                </v-col>
              </v-row>
            </v-container>
            <!--<small>*indicates required field</small>-->
          </v-card-text>
          <v-card-actions>
            <v-spacer>
            </v-spacer>
            <v-btn
              color="blue darken-1"
              text
              @click="printDialog = false"
            >
              닫기
            </v-btn>
          </v-card-actions>
        </v-card>
      </v-dialog>
    </div>

    <div data-app>
    <v-dialog
      v-model="clientFlag"
      persistent
      max-width="800px"
      id="user-info-modal"
    >
      <v-card>
        <v-card-title>
          <span class="text-h5">{{clientPopTitle}}</span>
        </v-card-title>
        <v-card-text class="regist-container">
          <v-container>
            <v-row>
              <v-col
                cols="12"
                md="12"
                class="client-col regist-col"
              >
                <CustPopup ref="custPopRef" v-if="clientFlag" @selectCustEvent="selectCustPop"></CustPopup>
              </v-col>
              <v-col
                cols="12"
                md="12"
                class="regist-col last justify-end"
              >
                <v-btn
                  color="blue darken-1"
                  text
                  @click="custInit()"
                >
                  초기화
                </v-btn>
                <v-btn
                  class="default-btn-style"
                  color="blue darken-1"
                  text
                  @click="clientFlag = false"
                >
                  닫기
                </v-btn>
              </v-col>
            </v-row>
          </v-container>
        </v-card-text>
      </v-card>
    </v-dialog>
    </div>
  </div>
</template>
<script>
import JSZip from 'jszip'
import CustPopup from '@/components/CustPopup.vue'
import { GridView, LocalDataProvider } from 'realgrid'
import { salseOrderfields, salseOrderColumns } from './gridData/SalesOrderSearch.js'
import { mapGetters } from 'vuex'
let mstGridView = GridView
let mstDataProvider = LocalDataProvider


export default {
  name: 'SalesSearch',
  components: {
    CustPopup
  },  
  data() {
    return {
      pageTitle:'매입내역 조회',
      cardTitle: '매입내역',
      clientFlag: false,
      dateToMain: false,
      occurrenceToMain: (new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10),
      dateFromMain: false,
      occurrenceFromMain: (new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10),
      clientPopFlag: false,
      clientPopTitle: '거래처 선택',
      curDate: '',
      custInsList: [],
      custList: [],
      strCustCd: '',
      strCustNm: '',
      deptList: [],
      strDeptCd: '',
      strDeptNm: '',
      mstListData: [
      ],
      ownerKey: '',
      userId: '',
      strAgentCd: '',
      locationVal: '',
      processingVal: '',
      deliveryVal: '',
      printDialog: false
    }
  },
  created() {
    console.log('------- cust ---------')
    let info = JSON.parse(sessionStorage.getItem('userInfo'))
    var selectOwner = sessionStorage.getItem('selectOwner')

    this.ownerKey = selectOwner
    this.userId = info[0].userId
    

    if(this.codeInfoObj === '' || this.codeInfoObj === null){
      setTimeout(() => {
        this.initSettings()
        this.$loadingHide()
      }, 1000)
    }else{
      this.initSettings()
    }
  },
  methods: {
    initSettings(){
      this.custList = []
      for(var i=0; i<this.custInfoObj.length; i++){
        var item = {'custCd' : this.custInfoObj[i].custCd, 'custNm' : this.custInfoObj[i].custNm, 'agentCd' : this.custInfoObj[i].agentCd }
        if(this.custList.findIndex((items) => items.custCd == this.custInfoObj[i].custCd) === -1){
          this.custList.push(item)
        }
      }

      if(this.custList.length === 1){
        this.strCustCd = this.custList[0].custCd
        this.strCustNm = this.custList[0].custNm
        this.strAgentCd = this.custList[0].agentcd
      }
      // console.log(this.custList)
    },
    selectCustPop(popData){
      this.strCustCd = popData.custCd
      this.strCustNm = popData.custNm
      this.clientFlag = false
      this.deptList = []
      for(var i=0; i<this.custInfoObj.length; i++){
        var item = this.custInfoObj[i]

        if(item.custCd === this.strCustCd){
          this.deptList.push(item)
        }
      }
      if(this.deptList.length === 1){
        this.strDeptCd = this.deptList[0].deptCd
        this.strDeptNm = this.deptList[0].deptNm
      }
    },
    custInit(){
      this.strCustCd = ''
      this.strCustNm = ''
      this.strDeptCd = ''
      this.strDeptNm = ''
      this.clientFlag = false
    },
    searchBackOrderInfo() {
      let fromYmd = this.occurrenceFromMain.replace(/-/g, '')
      let toYmd = this.occurrenceToMain.replace(/-/g, '')

      if(this.strCustCd === ''){
        // alert('거래처를 선택해 주세요.')
        this.$swal({
            title: '거래처를 선택해 주세요.'
        })
        return
      }

      this.$loading.show({delay:0})
      this.$store.dispatch('apiSalesOrderInfoObj', {'ownerKey': this.ownerKey, 'fromDt':fromYmd, 'toDt':toYmd, 'custCd': this.strCustCd}).then(() => {       
        console.log(this.salesOrderObj)   
        if(this.salesOrderObj.code === 'OK') { 
            this.mstListData = []
            this.mstListData = this.salesOrderObj.sales
            mstDataProvider.setRows(this.mstListData)
        } else {
          //alert(this.backOrdInfoObj.message)
          this.$swal({
            title: this.salesOrderObj.message
          })
        }
      }).catch((error) => {
        // alert('ErrorCode = ' + error.response.status + ' / ' + error.message + '\n시스템에 이상이 있습니다. 다시 시도해 주세요.')
        console.log(error)
        this.$swal({
            title: 'ErrorCode = ' + error.response.code + ' / ' + error.message + '\n시스템에 이상이 있습니다. 다시 시도해 주세요.'
        })
      }).finally(() => {
        setTimeout(() => {
          this.$loadingHide()
        }, 300)
      })
    },
    exportExcel(){    
      if(this.strCustCd === ''){
        // alert('거래처를 선택해 주세요.')
        this.$swal({
            title: '거래처를 선택해 주세요.'
        })
        return
      }
      
      mstGridView.exportGrid({
          type: "excel",
          target: "local",
          fileName: "SalesReport.xlsx",
          showProgress: true,
          progressMessage: "엑셀 Export중입니다.",
          indicator: 'hidden',
          header: true,
          compatibility: '2010',
          linear: true,
          separateRows: true,
          allColumns:true,
          //hideColumns: ["deptCd", "pick_zone", "pick_seq"],
          lookupDisplay:true
      })
    },   
    printStockList() {
      let rows = mstGridView.getCheckedRows()

      if(this.strCustCd === ''){
        this.$swal({
            title: '거래처를 선택해 주세요.'
        })
        return
      }

      if (rows.length == 0) {
        this.$swal({
            title: '출력물을 선택해 주세요.'
        })
        return true
      }

      let ordArray = []
      var fileNames = []
      var argsArray = []
      
      for (var i in rows) {
        var data = mstDataProvider.getJsonRow(rows[i])
        console.log(data)
        if (ordArray.indexOf(data.ordNo) == -1) {
          ordArray.push(data.ordNo)
          let tmp = {
            'ordNo': data.ordNo,
            'ownerKey': this.ownerKey
          }
          argsArray.push(tmp)
          fileNames.push('CIMS_OMS_TransStatement')
        }
      }
      
      
    
      //let arg1 = {'ordNo': ordArray }
      //let arg2 = {'ownerKey': this.ownerKey}
      //argsArray.push(arg1)
      //argsArray.push(arg2)
      console.log(fileNames)
      console.log(argsArray)
      // 오즈 리포트 실행
      // alert(dataProvider.getRows(0, -1))
      this.printDialog = true
      // var fileNames = ['CIMS_OMS_TransStatement']
      // var argsArray = [{'ownerKey': this.ownerKey, 'fromDt':fromYmd, 'toDt':toYmd, 'custCd': custArray, 'ordSeq': ordSeqStr}]
      var paramData = this.$getOzViewData(fileNames, argsArray)
      console.log(paramData)
      setTimeout(() => {
        this.$refs.ozViewerRef.initOzExecution(paramData)
      }, 500)
    },
  },
  mounted() {
    // console.log(this.codeInfoObj)
    // console.log(this.ordCustCodeObj)

    // this.locationVal = this.locationOption[0]
    // this.processingVal = this.processingOption[0]
    // this.deliveryVal = this.deliveryOption[0]

    window.JSZip = window.JSZip || JSZip

    mstDataProvider = new LocalDataProvider(true)
    mstGridView = new GridView('master-grid')
    mstGridView.setDataSource(mstDataProvider)
    mstGridView.setCheckBar({
      visible: true
    })
    mstGridView.setStateBar({
      visible: false
    })
    mstGridView.setPasteOptions({
      enabled: false
    })
    mstGridView.setEditOptions({
      editable: false,
      updatable: false
    }),
    mstGridView.checkBar.mergeRule = "values['custNm'] + values['ordNo']";
    mstGridView.groupBy(["ordNo"])
    mstDataProvider.setFields(salseOrderfields)
    mstGridView.setColumns(salseOrderColumns)
    //mstGridView.setCheckableExpression("(values['print_yn'] = 'Y') AND (values['status'] = 'Y')", true);
    
    //mstGridView.setColumnProperty("cust_nm", "autoFilter", true)
    mstGridView.displayOptions.selectionStyle = "singleRow"
    mstGridView.displayOptions.fitStyle = "even"
    
  },
  computed: {
    ...mapGetters({
      codeInfoObj: 'getCodeData',
      custInfoObj: 'getCustMstData',
      salesOrderObj: 'getSalesOrderInfoObj'
    })
  }
}
</script>
