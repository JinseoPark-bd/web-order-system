<template>
  <div class="real-container">
    <v-row class="ui-row">
      <v-col
        cols="12"
        md="12"
        class="d-flex flex-row"
      >
        <h2 class="content-tit">
            {{pageTitle}}
        </h2>
        <div class="data-control">
          <button type="button" class="button search-btn" @click="resetClick()">
            <svg xmlns="http://www.w3.org/2000/svg" height="10px" viewBox="20 10 24 24" width="10px" fill="#ffffff"><path d="M20.9 41.7q-5.55-1.05-9.225-5.45T8 26.05q0-3.55 1.5-6.7Q11 16.2 13.75 14q.4-.3.95-.275.55.025.95.425.5.5.45 1.15-.05.65-.65 1.15-2.1 1.75-3.275 4.275Q11 23.25 11 26.05q0 4.7 2.9 8.175 2.9 3.475 7.35 4.475.55.1.925.55.375.45.375 1 0 .7-.5 1.125-.5.425-1.15.325Zm6.3 0q-.65.1-1.15-.325-.5-.425-.5-1.125 0-.55.375-1 .375-.45.925-.55 4.5-1 7.35-4.475 2.85-3.475 2.85-8.175 0-5.45-3.775-9.225Q29.5 13.05 24.05 13.05h-1L25 15q.4.4.4 1.05T25 17.1q-.45.45-1.1.45-.65 0-1.05-.45l-4.55-4.5q-.25-.25-.35-.5-.1-.25-.1-.55 0-.3.1-.55.1-.25.35-.5l4.55-4.55q.4-.4 1.05-.4t1.1.4q.4.45.4 1.1 0 .65-.4 1.05l-1.95 1.95h1q6.7 0 11.35 4.675 4.65 4.675 4.65 11.325 0 5.8-3.65 10.2-3.65 4.4-9.2 5.45Z"/></svg> 
            RESET
          </button>
          <button type="button" class="button data-add" @click="addClick()">
            <svg xmlns="http://www.w3.org/2000/svg" height="18px" viewBox="0 0 24 24" width="18px" fill="#807D79"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M13 7h-2v4H7v2h4v4h2v-4h4v-2h-4V7zm-1-5C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z"/></svg>
            추가
          </button>
          <button type="button" class="button data-save" @click="saveOrdClick()">
            <svg xmlns="http://www.w3.org/2000/svg" height="18px" viewBox="0 0 24 24" width="18px" fill="#807D79"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M2 1a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1H9.5a1 1 0 0 0-1 1v7.293l2.646-2.647a.5.5 0 0 1 .708.708l-3.5 3.5a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L7.5 9.293V2a2 2 0 0 1 2-2H14a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V2a2 2 0 0 1 2-2h2.5a.5.5 0 0 1 0 1H2z"/></svg>
            제품주문
          </button>
          <!--
            <button type="button" class="button data-delete" @click="removeOrdClick()">
            <svg xmlns="http://www.w3.org/2000/svg" height="18px" viewBox="0 0 24 24" width="18px" fill="#807D79"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M7 11v2h10v-2H7zm5-9C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z"/></svg>
            삭제
          </button>
          -->
        </div>
      </v-col>
      <v-col
        cols="12"
        md="6"
        lg="4"
        class="ui-col"
      >
      <label class="default-tit input-tit text-center" for="order-number">
          주문번호
        </label>
        <input type="text"
            class="default-input"
            id="order-number"
            disabled
            v-model="ordNumber"
            />
      </v-col>
      <v-col
        cols="12"
        md="6"
        lg="4"
        class="ui-col"
      >
      <label class="default-tit input-tit text-center" for="occurrence-start">
          주문일자
        </label>
        <input type="text"
            class="default-input"
            id="occurrence-start"
            disabled
            v-model="ordDate"
          />
      </v-col>
      <v-col
        cols="12"
        md="6"
        lg="4"
        class="ui-col client-ui"
      >
      <label class="default-tit input-tit text-center" for="client-tit">
          거래처
        </label>
        <div class="client-box">
          <input type="text"
            class="default-input client-input left"
            @click="clientFlag = true"
            id="client-tit"
            v-model="strCustCd"
            :disabled="(custList.length <= 1) || (ordItemRows.length > 0)"
          />
          <button type="button"
            @click="clientFlag = true"
            v-if="(custList.length > 1) && (ordItemRows.length === 0)"
            class="client-search-btn">
            <svg xmlns="http://www.w3.org/2000/svg" class="search-icon" height="24px" viewBox="0 0 24 24" width="24px" fill="#000000">
              <path d="M0 0h24v24H0z" fill="none"/>
              <path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/>
            </svg>
          </button>
          <input type="text" class="default-input client-input right" id="client-right" v-model="strCustNm" disabled/>
        </div>
      </v-col>
      <!-- 
      <v-col
        cols="12"
        md="4"
        class="ui-col client-ui impose-ui"
      >
      <label class="default-tit input-tit text-center" for="impose-tit">
          부과
        </label>
        <div class="client-box">
          <input type="text"
            class="default-input client-input left"
            id="impose-tit"
            v-model="strDeptCd"
            :disabled="deptList.length <= 1"
          />
          <button type="button"
            @click="imposeFlag = true"
            v-if="deptList.length > 1"
            class="client-search-btn">
            <svg xmlns="http://www.w3.org/2000/svg" class="search-icon" height="24px" viewBox="0 0 24 24" width="24px" fill="#000000">
              <path d="M0 0h24v24H0z" fill="none"/>
              <path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/>
            </svg>
          </button>
          <input type="text" class="default-input client-input right" id="impose-right" v-model="strDeptNm" disabled/>
        </div>
      </v-col>
      <v-col
        cols="12"
        md="4"
        class="ui-col"
      >
      <label class="default-tit input-tit text-center" for="select-name">
          주문구분
        </label>
        <multiselect
          id="select-name"
          v-model="locationVal"
          :options="locationOption"
          :multiple="false"
          selectLabel="추가"
          deselectLabel="제외"
          placeholder="주문구분을 선택해주세요."
          class="default-v-select text-ellip"
          track-by="name"
          label="name"><span slot="noResult">주문구분을 선택해주세요.</span></multiselect>
      </v-col>
      <v-col
        cols="12"
        md="4"
        class="ui-col"
      >
      <label class="default-tit input-tit text-center" for="processing-status">
          배송구분
        </label>
        <multiselect
          id="processing-status"
          v-model="deliveryVal"
          :options="deliveryOption"
          :multiple="false"
          selectLabel="추가"
          deselectLabel="제외"
          placeholder="배송구분을 선택해주세요."
          class="default-v-select text-ellip"
          track-by="name"
          label="name"><span slot="noResult">배송구분을 선택해주세요.</span></multiselect>
      </v-col>
      <v-col
        cols="12"
        md="4"
        class="ui-col"
      >
      <label class="default-tit input-tit text-center" for="reason-status">
          사유
        </label>
        <multiselect
          id="reason-status"
          v-model="processingVal"
          :options="processingOption"
          :multiple="false"
          selectLabel="추가"
          deselectLabel="제외"
          placeholder="사유를 선택해주세요."
          class="default-v-select text-ellip"
          track-by="name"
          label="name"><span slot="noResult">사유를 선택해주세요.</span></multiselect>
      </v-col> -->
    </v-row>
    <v-row class="ui-row">
      <v-col
        cols="12"
        md="12"
        class="ui-col d-flex flex-column"
      >
          <h3 class="grid-tit">{{cardTitle}}</h3>
          <!--<div id="master-left-data" class="real-grid"></div>-->
          <div id="master-grid" class="real-grid"></div>
      </v-col>
    </v-row>
    <div data-app>
    <v-dialog
      v-model="clientFlag"
      persistent
      max-width="700px"
      id="user-info-modal"
      class="client-popup"
    >
      <v-card>
        <v-card-title>
          <span class="text-h5">{{clientPopTitle}}</span>
        </v-card-title>
        <v-card-text class="regist-container">
          <v-container>
            <v-row>
              <v-col
                cols="12"
                md="12"
                class="client-col regist-col"
              >
                <CustPopup ref="custPopRef" v-if="clientFlag" @selectCustEvent="selectCustPop"></CustPopup>
              </v-col>
              <v-col
                cols="12"
                md="12"
                class="regist-col last justify-end"
              >
                <v-btn
                  color="blue darken-1"
                  text
                  @click="custInit()"
                >
                  초기화
                </v-btn>
                <v-btn
                  color="blue darken-1"
                  class="default-btn-style"
                  text
                  @click="clientFlag = false"
                >
                  닫기
                </v-btn>
              </v-col>
            </v-row>
          </v-container>
        </v-card-text>
      </v-card>
    </v-dialog>
    </div>
    <div data-app>
    <v-dialog
      v-model="imposeFlag"
      persistent
      max-width="500px"
      id="user-info-modal2"
    >
      <v-card>
        <v-card-title>
          <span class="text-h5">{{imposePopTitle}}</span>
        </v-card-title>
        <v-card-text>
          <v-container>
            <v-row>
              <v-col
                cols="12"
                md="12"
              >
                <ImposePopup ref="imposePopRef" v-if="imposeFlag" @selectImposeEvent="selectImposePop" v-bind:deptList="deptList"></ImposePopup>
              </v-col>
              <v-col
                cols="12"
                md="12"
              >
                <v-btn
                  color="blue darken-1"
                  text
                  @click="deptInit()"
                >
                  초기화
                </v-btn>
                <v-btn
                  color="blue darken-1"
                  text
                  @click="imposeFlag = false"
                >
                  닫기
                </v-btn>
              </v-col>
            </v-row>
          </v-container>
        </v-card-text>
      </v-card>
    </v-dialog>
    </div>
    <div data-app>
      <v-dialog
        v-model="registFlag"
        persistent
        max-width="1000px"
        id="user-info-modal3"
      >
        <v-card>
          <v-card-title>
            <span class="text-h5">{{registPopTitle}}</span>
          </v-card-title>
          <v-card-text class="regist-container">
            <v-container>
              <v-row>
                <v-col
                  cols="12"
                  md="12"
                  class="regist-col"
                >
                  <RegistPopup ref="registPopRef" v-if="registFlag" @selectRegistEvent="selectRegistPop" v-bind:ordPropObj="ordPopsObj"></RegistPopup>
                </v-col>
                <v-col
                  cols="12"
                  md="12"
                  class="regist-col last justify-end"
                >
                  <v-btn
                    class="default-btn-style"
                    color="blue darken-1"
                    text
                    @click="registFlag = false"
                  >
                    닫기
                  </v-btn>
                </v-col>
              </v-row>
            </v-container>
          </v-card-text>
        </v-card>
      </v-dialog>
    </div>
  </div>
</template>
<script>
import CustPopup from '@/components/CustPopup.vue'
import ImposePopup from '@/components/ImposePopup.vue'
import RegistPopup from '@/components/RegistPopup.vue'
import { GridView, LocalDataProvider } from 'realgrid'
import { ordRegFields, ordRegColumns } from './gridData/OrderRegister.js'
import { mapGetters } from 'vuex'
// import OZViewer from '../../components/OZViewer.vue'

let gridView = GridView
let dataProvider = LocalDataProvider

export default {
  name: 'CustInspect',
  components: {
    CustPopup,
    ImposePopup,
    RegistPopup
  },  
  data() {
    return {
      pageTitle:'제품주문',
      cardTitle: '주문상세 내역',
      clientFlag: false,
      imposeFlag: false,
      registFlag: false,
      dateFromMain: false,
      occurrenceMainDate: (new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10),
      locationOption: [
        
      ],
      locationVal: '',
      processingOption: [
       
      ],
      processingVal: '',
      deliveryOption: [
        
      ],
      deliveryVal: '',
      clientPopFlag: false,
      clientPopTitle: '거래처 선택',
      imposePopFlag: false,
      imposePopTitle: '부과 선택',
      registPopFlag: false,
      registPopTitle: '제품 등록',
      custInsList: [],
      mstListData: [
      ],
      ownerKey: '',
      userId: '',
      strAgentCd: '',
      ordNumber: '',
      ordNo: '',
      ordDate: '',
      custList: [],
      strCustCd: '',
      strCustNm: '',
      deptList: [],
      strDeptCd: '',
      strDeptNm: '',
      ordPopsObj: '',
      ordItemRows: []
    }
  },
  created() {
    var info = JSON.parse(sessionStorage.getItem('userInfo'))
    var selectOwner = sessionStorage.getItem('selectOwner')
    this.ownerKey = selectOwner
    this.userId = info[0].userId
    

    if(this.codeInfoObj === '' || this.codeInfoObj === null){
      setTimeout(() => {
        this.initSettings()
        this.initOrder()
        this.$loadingHide()
      }, 1000)
    }else{
      this.initSettings()
      this.initOrder()
    }
    
    
  },
  methods: {
    initSettings(){
      this.custList = []
      console.log(this.custInfoObj)
      for(var i=0; i<this.custInfoObj.length; i++){
        var item = {'custCd' : this.custInfoObj[i].custCd, 'custNm' : this.custInfoObj[i].custNm, 'agentCd' : this.custInfoObj[i].agentCd }
        /*console.log('item ==============')
        console.log(item)
        console.log(this.custList.findIndex((items) => items.custCd == this.custInfoObj[i].custCd))*/
        if(this.custList.findIndex((items) => items.custCd == this.custInfoObj[i].custCd) === -1){
          this.custList.push(item)
        }
      }

      if(this.custList.length === 1){
        this.strCustCd = this.custList[0].custCd
        this.strCustNm = this.custList[0].custNm
        this.strAgentCd = this.custList[0].agentCd

        this.deptList = []
        for(var idx=0; idx<this.custInfoObj.length; idx++){
          var deptItem = this.custInfoObj[idx]

          if(item.custCd === this.strCustCd){
            this.deptList.push(deptItem)
          }
        }
        
        if(this.deptList.length > 0){
          this.strDeptCd = this.deptList[0].deptCd
          this.strDeptNm = this.deptList[0].deptNm
        }
        //this.setOrdType()
      }
      
      this.deliveryOption = [
        
      ]
      for(var j=0; j<this.codeInfoObj.length; j++){
        if(this.codeInfoObj[j].mstCode === 'DELICD'){
          
          // JNJ 하드코딩
          /*if(this.codeInfoObj[j].dtlCode === '001'){
            this.codeInfoObj[j].dtlCodeNm = '일반배송'
          }else if(this.codeInfoObj[j].dtlCode === '003'){
            this.codeInfoObj[j].dtlCodeNm = '응급배송(퀵 배송)'
          }else{
            continue
          }*/

          var divItem = {'name' : this.codeInfoObj[j].dtlCodeNm, 'value' : this.codeInfoObj[j].dtlCode}

          console.log(this.codeInfoObj[j].dtlCodeNm + '/ ' + this.codeInfoObj[j].dtlCode)

          this.deliveryOption.push(divItem)
        }
      }

      this.processingOption = [
        
      ]
      for(var k=0; k<this.codeInfoObj.length; k++){
        if(this.codeInfoObj[k].mstCode === 'RESCD'){
          var ordItem = {'name' : this.codeInfoObj[k].dtlCodeNm, 'value' : this.codeInfoObj[k].dtlCode}
          this.processingOption.push(ordItem)
        }
      }

      // console.log(this.custList)
    },
    getAgentCd(custCd){
      console.log('getAgentCd ========= ')
      console.log(this.custList)
      var divObj = this.custList.find((e) => e.custCd === custCd)
      console.log(divObj)
      return divObj.agentCd
    },
    selectCustPop(popData){
      this.strCustCd = popData.custCd
      this.strCustNm = popData.custNm

      this.strAgentCd = this.getAgentCd(this.strCustCd)
      console.log(popData)
      this.clientFlag = false

      this.deptList = []
      for(var i=0; i<this.custInfoObj.length; i++){
        var item = this.custInfoObj[i]

        if(item.custCd === this.strCustCd){
          this.deptList.push(item)
        }
      }
      
      if(this.deptList.length > 0){
        this.strDeptCd = this.deptList[0].deptCd
        this.strDeptNm = this.deptList[0].deptNm
      }

      //this.setOrdType()

    },
    selectImposePop(popData){
      console.log('selectImposePop ===========')
      console.log(popData)
      this.strDeptCd = popData.deptCd
      this.strDeptNm = popData.deptNm
      this.imposeFlag = false  
    },
    /*setOrdType(){
      //console.log('setOrdType')
      //console.log(this.ordCustCodeObj)
      this.locationOption = [
        
      ]
      for(var i=0; i<this.ordCustCodeObj.length; i++){
        if(this.ordCustCodeObj[i].custCd === this.strCustCd){
          if(this.ordCustCodeObj[i].ordCd !== 'EMG'){
          var ordItem = {'name' : this.ordCustCodeObj[i].ordCdNm, 'value' : this.ordCustCodeObj[i].ordCd}
          this.locationOption.push(ordItem)
          }
        }
      }
    },*/
    resetClick(){
      const resetConfirm = confirm('초기화를 진행하시겠습니까?')
      if (resetConfirm === true) {
        gridView.commit()
        this.initOrder()
        dataProvider.setRows(this.ordItemRows)
        gridView.refresh()
      } else {
        return false
      }
    },
    addClick(){
      if(this.strCustCd !== ''){
        gridView.commit()
        this.ordPopsObj = {'custCd' : this.strCustCd, 'ownerKey': this.ownerKey}
        this.registFlag = true
      }else{
        alert('거래처를 입력해주세요.')
      }
    },
    initOrder(){
      if (sessionStorage.getItem('ordInfo') !== null && sessionStorage.getItem('ordInfo') !== '') {
        console.log(sessionStorage.getItem('ordInfo'))
        var ordInfo = JSON.parse(sessionStorage.getItem('ordInfo'))
        sessionStorage.removeItem('ordInfo')

        this.searchDtlOrder(ordInfo)
        
      }else{
        this.ordNumber = 'New'
        this.ordNo = 'New'
        this.ordDate = this.occurrenceMainDate.replace(/-/g, '')
        this.processingVal = ''
        this.deliveryVal = '001'
        this.ordItemRows = []
        
        this.custInit()
      }
    },
    custInit(){
      this.strCustCd = ''
      this.strCustNm = ''
      this.strDeptCd = ''
      this.strDeptNm = ''
      this.clientFlag = false
      this.locationVal = ''
      this.locationOption = []

      if(this.custList.length === 1){
        this.strCustCd = this.custList[0].custCd
        this.strCustNm = this.custList[0].custNm
        this.strCustNm = this.custList[0].agentCd

        this.deptList = []
        for(var idx=0; idx<this.custInfoObj.length; idx++){
          var deptItem = this.custInfoObj[idx]

          if(deptItem.custCd === this.strCustCd){
            this.deptList.push(deptItem)
          }
        }
        
        if(this.deptList.length === 1){
          this.strDeptCd = this.deptList[0].deptCd
          this.strDeptNm = this.deptList[0].deptNm
        }
        //this.setOrdType()
      }
    },
    deptInit(){
      this.strDeptCd = ''
      this.strDeptNm = ''
      this.imposeFlag = false  
    },
    selectRegistPop(obj){
      // this.ordItemRows = obj
      this.registFlag = false
      console.log('=================== selectRegistEvent 호출')
      this.ordItemRows = dataProvider.getJsonRows()

      gridView.commit()
      for(var i=0; i<obj.length; i++){
        var item = obj[i]
        item.ordQty = 1
        var flag = true
        for(var j=0; j<this.ordItemRows.length; j++){
          console.log(item.itemCd + ' / ' + this.ordItemRows[j].itemCd  + ' / ' + (item.itemCd === this.ordItemRows[j].itemCd))

          if(item.itemCd === this.ordItemRows[j].itemCd){
            flag = false
            break
          }
        }
        if(flag){
          item.itemSub = '삭제'
          this.ordItemRows.push(item)
        }

        console.log('=================== i = ' + i)
      }
      console.log('=================== selectRegistEvent')
      console.log(this.ordItemRows)
      dataProvider.setRows(this.ordItemRows)
      gridView.refresh()

    },
    saveOrdClick(){
      var flag = ''
      if(this.ordItemRows.length > 0){
        console.log('this.ordNumber' + this.ordNumber)
        if(this.ordNumber === 'New'){
          flag = 'I'
        }else{
          flag = 'U'
        }

        if(this.strCustCd === ''){
          this.$swal({
            title: '거래처를 입력해주세요'
          })
          return
        }

        if(this.strDeptCd === ''){
          this.$swal({
            title: '부과정보가 없습니다. 담당자에게 문의해주세요.'
          })
          return
        }
      

        /*if(this.deliveryVal === ''){
          alert('배송구분을 입력해주세요')
          return
        }*/

      }else{
        if(this.ordNumber === 'New'){
          this.$swal({
            title: '주문할 제품이 존재하지 않습니다.'
          })
          // alert('주문할 제품이 존재하지 않습니다.')
          return
        }else{
          flag = 'D'
        }
      }

      const saveConfirm = confirm('제품을 주문하시겠습니까?')
      if (saveConfirm === true) {
        gridView.commit()
        this.saveOrdData(flag)
      } else {
        return false
      }

    },
    saveOrdData(tranFlag){
      // console.log('tranFlag' + tranFlag)
      var ordCd = ''
      var divCd = ''
      var resCd = ''

      // 하드코딩 추후 변경 해야할 것으로 보여짐
      if(this.ownerKey === 'A08462'){
        ordCd = 'NML'
        divCd = '001'
        resCd = '002'
      }else if(this.ownerKey === 'A35400'){
        ordCd = 'SAL'
        divCd = '002'
        resCd = '001'
      }else{
        ordCd = 'NML'
        divCd = '001'
        resCd = '002'
      }

      var mstInfo ={
        'ownerKey': this.ownerKey,
        'disOrdNo': this.ordNumber,
        'ordNo': this.ordNo,
        'agentCd': this.strAgentCd,
        'custCd': this.strCustCd,
        'custNm': this.strCustNm,
        'deptCd': this.strDeptCd,
        'deptNm': this.strDeptNm,
        'ordDt': this.ordDate,
        'ordCd': ordCd,
        'divCd': divCd,
        'resCd': resCd,
        'useYn': 'Y',
        'remark': '',
        'userId': this.userId,
        'tranFlag' : tranFlag
      }

      this.ordItemRows = dataProvider.getJsonRows()

      this.$store.dispatch('apiOrdSaveInfo', {'ordMst': mstInfo, 'ordDtl': this.ordItemRows}).then(() => {
        this.$loading.show({delay:0})
        if(this.ordSaveObj.code === 'OK') {
          this.$swal({
            title: '고객님의 주문이 완료되었습니다.'
          })
          // alert('고객님의 주문이 완료되었습니다.')
          // this.initOrder()
        } else {
          alert(this.ordSaveObj.message)
        }
      }).catch((error) => {
        this.$swal({
            title: 'ErrorCode = ' + error.response.status + ' / ' + error.message + '\n시스템에 이상이 있습니다. 다시 검색해 주세요.'
        })
        //alert('ErrorCode = ' + error.response.status + ' / ' + error.message + '\n시스템에 이상이 있습니다. 다시 검색해 주세요.')
      }).finally(() => {
        setTimeout(() => {
          this.$loadingHide()
        }, 300);
      })

    
    },
    removeOrdClick(){
      var checkrows = gridView.getCheckedRows()

      if (checkrows.length === 0) {
        this.$swal({
            title: '삭제할 데이터가 존재하지 않습니다'
        })
        // alert('삭제할 데이터가 존재하지 않습니다')
        return
      }

      for(var i=0; i<checkrows.length; i++){
        
        var item = dataProvider.getJsonRow(checkrows[i])        
        for(var j=0; j<this.ordItemRows.length; j++){
          console.log(item.itemCd + ' / ' + this.ordItemRows[j].itemCd  + ' / ' + (item.itemCd === this.ordItemRows[j].itemCd))
          if(item.itemCd === this.ordItemRows[j].itemCd){
            this.ordItemRows.splice(j, 1)
            break
          }
        }
      }
      
      //console.log('=================== removeOrdData')
      //console.log(this.ordItemRows)
      dataProvider.setRows(this.ordItemRows)
      gridView.refresh()
    },
    searchDtlOrder(obj) {
      this.$loading.show({delay:0})
      //var params = {'userId' : this.userId, 'ownerKey': this.ownerKey, 'custCd': this.strCustCd, 'fromDt': this.occurrenceFromMain.replace(/-/g, ''), "toDt":this.occurrenceToMain.replace(/-/g, '')}
      this.$store.dispatch('apiOrdDtlInfo', obj).then(() => {
        if(this.ordDtlObj.code === 'OK') {
          // console.log(this.ordDtlObj)
          var ordMst = this.ordDtlObj.ordMstInfo
          this.ordItemRows = this.ordDtlObj.ordDtlInfo
          
          // console.log(this.ordItemRows)

          this.ownerKey = ordMst.ownerKey
          this.ordNumber = ordMst.disOrdNo
          this.ordNo = ordMst.ordNo
          this.strAgentCd = ordMst.agentCd
          this.strCustCd = ordMst.custCd
          this.strCustNm = ordMst.custNm
          this.strDeptCd = ordMst.deptCd
          this.strDeptNm = ordMst.deptNm
          this.ordDate = ordMst.ordDt

          //this.setOrdType()

          this.locationVal = this.findValueObj(this.locationOption, ordMst.ordCd)
          this.deliveryVal = this.findValueObj(this.deliveryOption, ordMst.divCd)
          this.processingVal = this.findValueObj(this.processingOption, ordMst.resCd)

          for(var i=0; i<this.ordItemRows.length; i++){
            this.ordItemRows[i].itemSub = '삭제'
          }
          
          dataProvider.setRows(this.ordItemRows)

        } else {
          this.$swal({
            title: this.ordDtlObj.message
          })
          // alert(this.ordDtlObj.message)
        }
      }).catch((error) => {
        this.$swal({
            title: 'ErrorCode = ' + error.message + '\n시스템에 이상이 있습니다. 다시 검색해 주세요.'
        })
        // alert('ErrorCode = ' + error.message + '\n시스템에 이상이 있습니다. 다시 검색해 주세요.')
      }).finally(() => {
        setTimeout(() => {
          this.$loadingHide()
        }, 300)
      })
    },
    findValueObj(array, str){
      for(var i=0; i<array.length; i++){
        if(array[i].value === str){
          return array[i]
        }
      }
      return ''
    },
    subItems (rowNum) {
      console.log(rowNum)
      dataProvider.removeRow(rowNum)
      this.ordItemRows = dataProvider.getJsonRows()
      dataProvider.setRows(this.ordItemRows)
      gridView.refresh()
      
    }
  },
  mounted() {

    var tmpThis = this
    dataProvider = new LocalDataProvider(true)
    gridView = new GridView('master-grid')
    gridView.setDataSource(dataProvider) 
    gridView.setStateBar({
      visible: false
    })
    gridView.setPasteOptions({
      enabled: false
    })
    gridView.setEditOptions({
      editable: true,
      editWhenFocused: true,
      editWhenClickFocused: true,
      enterToNextRow : true,
      commitWhenLeave: true
    })
    gridView.setCheckBar({
      visible: false
    })
    dataProvider.setFields(ordRegFields)
    gridView.setColumns(ordRegColumns)
    gridView.displayOptions.fitStyle = 'even'
    gridView.columnByName('avaYn').displayCallback = function (grid, index) {
      let avaQty = grid.getValue(index.dataRow,'avaQty')
      if(avaQty > 0){
        return 'Y'
      }else{
        return 'N'
      }
      
    }

    gridView.onCellItemClicked = function (grid, index, clickData) {
      
      if (clickData.column === 'itemSub') {
        gridView.commit()
        tmpThis.subItems(clickData.dataRow)
      }
      
      return true;
    }
    gridView.onValidateColumn =  function (grid, column, inserting, value, itemIndex) {      
      if (column.name === "ordQty") {    
        
        let reqQty = grid.getValue(itemIndex,'ordQty')
        let nag = reqQty % 1
      
        
        if(reqQty <= 0 || Object.is((reqQty), NaN)){
          tmpThis.$swal({
            title: '수량에 들어갈 수 없는 값 입니다.'
          })
          // alert('수량에 들어갈 수 없는 값 입니다.')
          grid.setValue(itemIndex, 'ordQty',1)
          
        }

        if(nag > 0){
          // 소수점 버림
          grid.setValue(itemIndex, 'ordQty', Math.floor(reqQty))
        }

      }
      
      if (column.name === "remark") {    
        // 리마크 길이 조절을 위한 설정
        let remarkVal = grid.getValue(itemIndex,'remark')

        // console.log(typeof remarkVal !== 'undefined')
        if(typeof remarkVal !== 'undefined'){
          if(remarkVal.length > 100){
            tmpThis.$swal({
              title: '비고는 최대 100글자까지 입력이 가능합니다.'
            })
            // alert('비고는 최대 100글자까지 입력이 가능합니다.')
            grid.setValue(itemIndex, 'remark', remarkVal.substr(0,100))
          }
        }
        
      }
    }
    // mstGridView.setColumnProperty("ymd", "autoFilter", true)
  
    /* gridView.onItemChecked = function (grid, itemIndex, checked) {      
      console.log(grid + ' - ' + itemIndex + ' - ' + checked)
      var rowDatas = []
      var rows = grid.getCheckedRows()
      for (var i in rows) {
        var data = dataProvider.getJsonRow(rows[i])
        rowDatas.push(data)
      }
      alert(JSON.stringify(rowDatas))
    } */
    gridView.refresh()
    //gridView.checkBar.mergeRule = "value['cust_nm']"
    // this.searchMstOrder()
  },
  computed: {
    ...mapGetters({
      codeInfoObj: 'getCodeData',
      custInfoObj: 'getCustMstData',
      ordCustCodeObj: 'getOrdCodeData',
      ordSaveObj: 'getOrdSaveInfo',
      ordMstObj: 'getOrdMstInfo',
      ordDtlObj: 'getOrdDtlInfo'
    })
  }
}
</script>
