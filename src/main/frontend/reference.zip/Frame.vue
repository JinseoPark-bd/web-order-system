<template>
  <div class="oms-template" :class="{'asideCtrl': asideCtrl}">
    <header class="oms-header">
      <div class="logo-area" :class="{'small': sideExpand}">
        <h1 class="logo" :class="{'asideCtrl': asideCtrl}">
          <router-link to="/main">
            <img v-if="sideExpand" src="../../img/oms-small-logo.png" alt="OMS">
            <img v-else src="../../img/oms-default-logo.png" alt="OMS">
          </router-link>
        </h1>
        <button type="button" data-hidden="desktop" @click="asideCtrl = !asideCtrl" class="hamburger" id="hamburger-11" :class="{'is-active': asideCtrl}">
            <span class="line"></span>
            <span class="line"></span>
            <span class="line"></span>
        </button>
      </div>
    </header>
    <div class="oms-gnb" v-if="customerGnb">
      <div class="inner" v-if="customerOption.length > 1">
        <label for="customer-name" class="default-label">화주: </label>
        <multiselect
          id="customer-name"
          v-model="customerVal"
          :options="customerOption"
          :multiple="false"
          selectLabel="추가"
          deselectLabel="선택중"
          placeholder="화주를 선택해주세요."
          class="default-v-select text-ellip"
          track-by="name"
          :searchable="true"
          :allow-empty="false"
          @select="ownerSelectEvent"
          label="name"><span slot="noResult">화주를 선택해주세요.</span>
        </multiselect>
      </div>
    </div>
    <aside class="oms-aside" :class="{'mobile': asideCtrl}">
      <div class="btns-area" :class="{'mobile': asideCtrl}">
        <v-tooltip bottom>
          <template v-slot:activator="{ on, attrs }">
            <button type="button" class="user-btn menu" v-bind="attrs" v-on="on" @click.stop="sideExpand = !sideExpand">
              <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 0 24 24" width="24px" fill="#BDBCBB"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"/></svg>
            </button>
          </template>
          <span>메뉴</span>
        </v-tooltip>
        <v-tooltip bottom>
          <template v-slot:activator="{ on, attrs }">
            <button type="button" class="user-btn" v-bind="attrs" v-on="on" @click="viewUserInfo">
              <svg xmlns="http://www.w3.org/2000/svg" v-if="!asideCtrl" height="24px" viewBox="0 0 24 24" width="24px" fill="#BDBCBB"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zM7.07 18.28c.43-.9 3.05-1.78 4.93-1.78s4.51.88 4.93 1.78C15.57 19.36 13.86 20 12 20s-3.57-.64-4.93-1.72zm11.29-1.45c-1.43-1.74-4.9-2.33-6.36-2.33s-4.93.59-6.36 2.33C4.62 15.49 4 13.82 4 12c0-4.41 3.59-8 8-8s8 3.59 8 8c0 1.82-.62 3.49-1.64 4.83zM12 6c-1.94 0-3.5 1.56-3.5 3.5S10.06 13 12 13s3.5-1.56 3.5-3.5S13.94 6 12 6zm0 5c-.83 0-1.5-.67-1.5-1.5S11.17 8 12 8s1.5.67 1.5 1.5S12.83 11 12 11z"/></svg>
              <svg xmlns="http://www.w3.org/2000/svg" v-else height="24px" viewBox="0 0 24 24" width="24px" fill="#BDBCBB"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zM7.07 18.28c.43-.9 3.05-1.78 4.93-1.78s4.51.88 4.93 1.78C15.57 19.36 13.86 20 12 20s-3.57-.64-4.93-1.72zm11.29-1.45c-1.43-1.74-4.9-2.33-6.36-2.33s-4.93.59-6.36 2.33C4.62 15.49 4 13.82 4 12c0-4.41 3.59-8 8-8s8 3.59 8 8c0 1.82-.62 3.49-1.64 4.83zM12 6c-1.94 0-3.5 1.56-3.5 3.5S10.06 13 12 13s3.5-1.56 3.5-3.5S13.94 6 12 6zm0 5c-.83 0-1.5-.67-1.5-1.5S11.17 8 12 8s1.5.67 1.5 1.5S12.83 11 12 11z"/></svg>
            </button>
          </template>
          <span>개인정보 변경</span>
        </v-tooltip>
        <v-tooltip bottom>
          <template v-slot:activator="{ on, attrs }">
            <button type="button" class="user-btn" v-bind="attrs" v-on="on" @click="viewPassword">
              <svg xmlns="http://www.w3.org/2000/svg" v-if="!asideCtrl" height="20px" viewBox="0 0 16 16" width="20px" fill="#BDBCBB"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M8 1a2 2 0 0 1 2 2v4H6V3a2 2 0 0 1 2-2zm3 6V3a3 3 0 0 0-6 0v4a2 2 0 0 0-2 2v5a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2z"/></svg>
              <svg xmlns="http://www.w3.org/2000/svg" v-else height="20px" viewBox="0 0 16 16" width="20px" fill="#BDBCBB"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M8 1a2 2 0 0 1 2 2v4H6V3a2 2 0 0 1 2-2zm3 6V3a3 3 0 0 0-6 0v4a2 2 0 0 0-2 2v5a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2z"/></svg>
            </button>
          </template>
          <span>비밀번호 변경</span>
        </v-tooltip>
        <v-tooltip bottom>
          <template v-slot:activator="{ on, attrs }">
            <button type="button" class="user-btn" v-bind="attrs" v-on="on" @click="logout">
              <svg xmlns="http://www.w3.org/2000/svg" v-if="!asideCtrl" height="24px" viewBox="0 0 24 24" width="24px" fill="#BDBCBB"><path d="M0,0h24v24H0V0z" fill="none"/><path d="M17,8l-1.41,1.41L17.17,11H9v2h8.17l-1.58,1.58L17,16l4-4L17,8z M5,5h7V3H5C3.9,3,3,3.9,3,5v14c0,1.1,0.9,2,2,2h7v-2H5V5z"/></svg>
              <svg xmlns="http://www.w3.org/2000/svg" v-else height="24px" viewBox="0 0 24 24" width="24px" fill="#BDBCBB"><path d="M0,0h24v24H0V0z" fill="none"/><path d="M17,8l-1.41,1.41L17.17,11H9v2h8.17l-1.58,1.58L17,16l4-4L17,8z M5,5h7V3H5C3.9,3,3,3.9,3,5v14c0,1.1,0.9,2,2,2h7v-2H5V5z"/></svg>
            </button>
          </template>
          <span>로그아웃</span>
        </v-tooltip>   
      </div>
      <div class="user-area" :class="{'non-expanded': sideExpand}">
        <div class="profile" :class="{'profile-jnj': ownerKey === 'A08462', 'profile-mkv': ownerKey === 'A35400'}">
          <strong class="position">{{mainUserId}}</strong>
          <span class="user">{{mainUserName}}</span>
          <i class="logo" v-if="ownerKey === 'A35400'"></i>
        </div>
        <div class="aside-menu">
          <v-list 
            v-for="item in items" 
            :key="item.title"
            class="menu-list"
          >
            <div v-if="!item.items">
              <v-list-item 
                
                class="item-btn"
                active-class="router-link-exact-active"
              >
                <v-list-item-title>{{item.title}}</v-list-item-title>
              </v-list-item>
            </div>
            <v-list-group
              v-else
              no-action
              v-model="item.active"
            >
              <template v-slot:activator>
                <v-list-item-title>{{item.title}}</v-list-item-title>
              </template>
              <div
                v-for="item in item.items"
                :key="item.title"
              >
                <v-list-item 
                  :to="item.route"
                  :class="{'mobile': asideCtrl}"
                  active-class="router-link-exact-active"
                  @click="menuClick(item, asideCtrl)"
                >
                  <v-list-item-title>{{item.title}} </v-list-item-title>
                </v-list-item>
              </div>
            </v-list-group>
          </v-list>
        </div>
        <button type="button" class="pl-btn" @click="menuClick('PersonalInformation_version2')" v-if="ownerKey === 'A08462'">개인정보 처리방침</button>
      </div>
    </aside>
    <div data-app>
      <v-dialog
        v-model="dialog"
        persistent
        max-width="400px"
        id="user-info-modal"
      >
        <v-card>
          <v-card-title>
            <span class="text-h5">사용자 정보</span>
          </v-card-title>
          <v-card-text>
            <v-container>
              <v-row>
                <v-col
                  cols="12"
                  md="12"
                >
                  <v-text-field
                    label="ID*"
                    required
                    v-model="userId"
                    disabled
                    oninput="javascript: this.value = this.value.replace(/[ㄱ-ㅎ|ㅏ-ㅣ|가-힣]/g, '' );"
                  ></v-text-field>
                </v-col>
              </v-row>
              <v-row>
                <v-col 
                  cols="12"
                  md="12">
                  <v-text-field
                    label="이름"
                    required
                    v-model="userName"
                    disabled
                  ></v-text-field>
                </v-col>
              </v-row>
              <v-row>
                <v-col 
                  cols="12"
                  md="12">
                  <v-text-field
                    label="전화번호"
                    required
                    v-model="userTel"
                  ></v-text-field>
                </v-col>
              </v-row>
              <v-row>
                <v-col 
                  cols="12"
                  md="12">
                  <v-text-field
                    label="Email"
                    required
                    v-model="userEmail"
                  ></v-text-field>
                </v-col>
              </v-row>
            </v-container>
            <!--<small>*indicates required field</small>-->
          </v-card-text>
          <v-card-actions>
            <v-spacer class="d-flex justify-end">
              <v-btn
                class="default-btn-style"
                color="blue darken-1"
                text
                @click="setChangeUserInfo()"
              >
                저장
              </v-btn>
              <v-btn
                class="close-btn-style"
                color="blue darken-1"
                style="margin-left:10px"
                text
                @click="dialog = false"
              >
                닫기
              </v-btn>
            </v-spacer>
          </v-card-actions>
        </v-card>
      </v-dialog>
    </div>

    <div data-app>
      <v-dialog
        v-model="passwordDialog"
        persistent
        max-width="400px"
        id="user-info-modal"
      >
        <v-card>
          <v-card-title>
            <span class="text-h5">비밀번호 변경</span>
          </v-card-title>
          <v-card-text>
            <v-container>
              <v-row>
                <v-col
                  cols="12"
                  md="12"
                >
                  <v-text-field
                    label="ID*"
                    required
                    v-model="userId"
                    disabled
                    oninput="javascript: this.value = this.value.replace(/[ㄱ-ㅎ|ㅏ-ㅣ|가-힣]/g, '' );"
                  ></v-text-field>
                </v-col>
              </v-row>
              <v-row>
                <v-col 
                  cols="12"
                  md="12">
                  <v-text-field
                    type="password"
                    label="이전 Password"
                    required
                    maxlength="20"
                    v-model="prePassword"
                  ></v-text-field>
                </v-col>
              </v-row>
              <v-row>
                <v-col 
                  cols="12"
                  md="12">
                  <v-text-field
                    type="password"
                    label="변경 Password"
                    required
                    v-model="nextPassword"
                    maxlength="20"
                    :rules="rules"
                  ></v-text-field>
                </v-col>
              </v-row>
              <v-row>
                <v-col 
                  cols="12"
                  md="12">
                  <v-text-field
                    type="password"
                    label="변경 Password 확인"
                    required
                    v-model="confirmPassword"
                    maxlength="20"
                    :rules="rulesCheck"
                  ></v-text-field>
                </v-col>
              </v-row>
              <v-row>
                <v-col 
                  cols="12"
                  md="12">
                  <span class="text-h6" style="color:rgba(255,0,0,.6)">숫자 + 문자 + 특수문자 포함 8~20자리로 설정해주세요.</span>
                  <span class="text-h6" style="color:rgba(255,0,0,.6)">사용 가능 특수 문자 : !@#$%^*+=-</span>
                </v-col>
              </v-row>
            </v-container>
            <!--<small>*indicates required field</small>-->
          </v-card-text>
          <v-card-actions>
            <v-spacer class="d-flex justify-end">
              <v-btn
                class="default-btn-style"
                color="blue darken-1"
                text
                @click="setChangePassword()"
              >
                저장
              </v-btn>
              <v-btn
                color="blue darken-1"
                class="close-btn-style"
                text
                style="margin-left:10px"
                @click="passwordDialog = false"
              >
                닫기
              </v-btn>
            </v-spacer>
          </v-card-actions>
        </v-card>
      </v-dialog>
    </div>
    <section class="oms-contents" :class="{'expanded': sideExpand}">
      <div class="tab-area">
        <router-tab />
      </div>
    </section>
  </div>
</template>

<!--<style lang="scss" scoped>
    .v-card__text{
      color: rgba(255,0,0,.6)
    }
</style>-->

<script>
import { mapGetters } from 'vuex'

export default {
  name: 'Main',
  components: {
    // Delivery
  },
  data() {
    return {
      dialog: false,
      passwordDialog: false,
      userId: '',
      userName: '',
      userGroup: '',
      userTel: '',
      userEmail: '',
      mainUserName: '관리자',
      mainUserId: 'MASTER',
      prePassword: '',
      nextPassword: '',
      confirmPassword: '',
      sideExpand: false,
      passFlag: false,
      checkFlag: false,
      rules: [
        value => this.setPassRules(value) 
        /*value => !!value || '비밀번호를 입력해주세요.',
        value => (/^(?=.*[a-zA-Z])(?=.*[!@#$%^*+=-])(?=.*[0-9]).{8,20}$/.test(value) === true) || '숫자,영문자,특수문자 조합 8~20자리로 사용해야 합니다.',
        value => (/(?=.*[^a-zA-Z0-9!@#$%^*+=-])/.test(value) === false) || '사용할 수 없는 문자가 있습니다.'*/

      ],
      rulesCheck: [
        value => this.setCheckRules(value)
        /*value => !!value || '비밀번호 확인을 입력해주세요.',
        value => value === this.nextPassword || '패스워드가 일치하지 않습니다'*/
      ],
      items: [
      //  { active: true,
      //     title: '주문 관리',
      //     items:[
      //       { title: '제품주문', route: '/OrderRegister' },
      //       { title: '주문/배송확인', route: '/OrderSearch' }
      //     ]
      //   },
      //   { active: true,
      //     title: '재고 관리',
      //     items:[
      //       { title: '백오더 조회', route: '/BackOrderSearch' },
      //       { title: '거래처별 재고조회', route: '/ClientStockSearch' }
      //     ]
      //   },
      ],
      customerOption: [],
      customerVal: '',
      customerGnb: true,
      firstYn: 'N',
      ownerKey: '',
      agentCd: '',
      asideCtrl: false,
      tabFlag: false
    }
  },
  created () {
    this.setSessionData()
    var info = JSON.parse(sessionStorage.getItem('userInfo'))
    // console.log('info' + JSON.stringify(info))
    this.ownerKey = info[0].ownerKey
    this.userId = info[0].userId
    //this.agentCd = info[0].agentCd

    sessionStorage.setItem('selectOwner', this.ownerKey)

    let uniqueKeys = []
    for (let i = 0; i < info.length; i++) {
      let flag = info[i].ownerNm
      
      if (uniqueKeys.indexOf(flag) === -1) {
        uniqueKeys.push(flag)
        let item = {
          'name': info[i].ownerNm,
          'value': info[i].ownerKey
        };
        this.customerOption.push(item);
      }
    }

    this.customerVal = this.customerOption[0]
    // this.setRouterInit()
    // this.customerVal.value = this.ownerKey

    if (sessionStorage.getItem('userInfo') === null) {
      alert('세션이 만료되어 로그인 페이지로 이동합니다.')
      sessionStorage.clear()
      this.$router.replace('/')
      return
    }else{
      this.callTotalInfo()
    }
    if (window.realGrid2Lic === ''){
      if (sessionStorage.getItem('realKey') === null) {
        alert('세션이 만료되어 로그인 페이지로 이동합니다.')
        sessionStorage.clear()
        this.$router.replace('/')
      } else {
        // var key = JSON.parse(sessionStorage.getItem('realKey'))
        var key = sessionStorage.getItem('realKey')
        window.realGrid2Lic = key
      }
    }
    this.firstYn = sessionStorage.getItem('firstYn')
    //console.log('this.firstYn = ' + this.firstYn)

    if(this.firstYn === 'Y'){
      sessionStorage.removeItem('firstYn')
      this.dialog = true
    }

  },
  methods: {
    setPassRules(value) {
      this.passFlag = false
      if (value === '') {
        return '비밀번호를 입력해주세요.'
      }else if (/^(?=.*[a-zA-Z])(?=.*[!@#$%^*+=-])(?=.*[0-9]).{8,20}$/.test(value) === false){
        return '숫자,영문자,특수문자 조합 8~20자리로 사용해야 합니다.'
      }else if (/(?=.*[^a-zA-Z0-9!@#$%^*+=-])/.test(value) === true) {
        return '사용할 수 없는 문자가 있습니다.'
      }else{
        this.passFlag = true
        return true
      }
    },
    // setRouterInit(){
    //   if(this.ownerKey === 'A35400'){
    //     this.items[0].items.unshift({ title: '제품주문(공통)', route: '/ComonOrderRegister' })
    //     this.items[1].items.push({ title: '거래명세서 조회', route: '/SalesSearch' })
    //   }else{
    //     this.items[0].items.unshift({ title: '제품주문', route: '/OrderRegister' })
    //     this.items[1].items.push({ title: '거래처별 재고조회', route: '/ClientStockSearch' })
    //   }
    // },
    setCheckRules(value){
      this.checkFlag = false
      if (value === '') {
        return '비밀번호 확인을 입력해주세요.'
      }else if(this.nextPassword === ''){
        return '변경 비밀번호를 입력해주세요'
      }else if (value !== this.nextPassword) {
        return '패스워드가 일치하지 않습니다'
      }else{
        this.checkFlag = true
        return true
      }
    },
    viewUserInfo() {
      // console.log(JSON.stringify(this.userInfo))
      this.dialog = true
      // alert('bookmarkMenu')
    },
    menuClick(obj){
      this.asideCtrl = false
      if(obj === 'PersonalInformation_version2'){
        this.$router.replace('/PersonalInformation_version2').catch(() => {})
        return false;
      }
      this.$router.replace(obj.route).catch(() => {})
    },
    getUserMenuSetting() {
    const info = JSON.parse(sessionStorage.getItem('userInfo'));
    this.$store.dispatch('apiUserMenu', {'rokey': info[0].groupCd })
        .then(() => {
          if (this.userMenu.code === 'OK') {
            for (let i = 0; i < this.userMenu.menuByRoleTreeSelect.length; i++) {
              const menu = this.userMenu.menuByRoleTreeSelect[i];

              if (menu.menutype !== 'menu' || menu.checked === 0) {
                continue;
              }

              const tmp = {
                active: true,
                title: menu.mename,
                items: [],
                mekey: menu.mekey
              };

              this.items.push(tmp);
            }

            for (let i = 0; i < this.userMenu.menuByRoleTreeSelect.length; i++) {
              const menuDt = this.userMenu.menuByRoleTreeSelect[i];
              
              if (menuDt.menutype !== 'page' || menuDt.checked === 0) {
                continue;
              }

              for (let j = 0; j < this.items.length; j++) {
                if (this.items[j].mekey === menuDt.uppermekey) {
                  const tmpDt = {
                    title: menuDt.mename,
                    route: menuDt.menupath
                  };
                  this.items[j].items.push(tmpDt);
                }
              }
            }
          } else {
            alert('사용자 정보 저장에 실패하였습니다.');
          }
        })
        .catch((error) => {
          alert(error);
        });
    },
    callTotalInfo(){
      this.$loading.show({delay:0})
        //this.$store.dispatch('apiTotalData',{ 'ownerKey' :this.ownerKey, 'userId' : this.userId, 'agentCd': this.agentCd}).then(() => {
        this.$store.dispatch('apiTotalData',{ 'ownerKey' :this.ownerKey, 'userId' : this.userId}).then(() => {
        if(this.totalInfoObj.code === 'SUCCESS') {
          // console.log('this.totalInfoObj')
          // this.dashInfo = this.dashInfoObj.dashInfo
          this.$store.commit('setCodeData', this.totalInfoObj.codeInfo)
          this.$store.commit('setCustMstData', this.totalInfoObj.mstInfo)
          this.$store.commit('setOrdCodeData', this.totalInfoObj.custOrdCode)
          
          var custList = this.totalInfoObj.mstInfo
          var tmpList = []

          for(var i=0; i<custList.length; i++){
            if(tmpList.indexOf(custList[i].agentCd) === -1){
              tmpList.push(custList[i].agentCd)
            }
          }

          this.$store.commit('setAgentCount', tmpList.length)

          // console.log(this.totalInfoObj.mstInfo)
          // console.log(this.codeInfoObj)
          // console.log(this.ordCustCodeObj)
          // console.log(this.custInfoObj)
        } 
         else {
          alert('거래처 정보 호출에 실패하였습니다.')
        } 
      }).catch((error) => {
        alert('ErrorCode = ' + ' / ' + error.message + '\n시스템에 이상이 있습니다. 다시 검색해 주세요.')
      }).finally(() => {
        setTimeout(() => {
          this.$loadingHide()
          if(this.tabFlag === true){
            this.$tabs.reset('main')
          }
        }, 300)
      })
    },
    viewPassword() {
      this.prePassword = ''
      this.nextPassword = ''
      this.confirmPassword = ''
      this.passFlag = false
      this.checkFlag = false
      this.passwordDialog = true
    },
    setChangeUserInfo(){
      // this.dialog = false
      // var tmpThis = this;
      if (this.userName === '') {
        alert('사용자 이름을 입력해주세요.')
        return false
      }
      // userName
      this.$store.dispatch('apiUserInfoTran', {'userId': this.userId, 'userName': this.userName, 'userTel': this.userTel, 'userEmail': this.userEmail, 'changeType': 'privteChange'}).then(() => {
        if(this.userTranRtn.code === 'SUCCESS') {
          this.dialog = false
          var info = {
            userId: this.userId,
            userTel: this.userTel,
            userEmail: this.userEmail
          }
          sessionStorage.setItem('userInfo', JSON.stringify(info))
          alert('개인 사용자 정보가 저장 되었습니다.')
          this.setSessionData()
        } else {
          alert('사용자 정보 저장에 실패하였습니다.')
        }
      }).catch((error) => {
        alert('ErrorCode = ' + error.response.status + ' / ' + error.message + '\n시스템에 이상이 있습니다. 다시 시도해 주세요.')
      })
    
      // alert('사용자 정보가 저장 되었습니다.')
    },
    setChangePassword(){
      // alert('password변경')

      if(this.passFlag === false) {
        alert('Password로 사용할 수 없습니다.\n다시 입력해 주세요.')
        return
      }

      if (this.nextPassword !== this.confirmPassword) {
        alert('입력한 패스워드가 다릅니다')
        return
      }
      this.$loading.show({delay:0})
      
      var obj = {userId: this.mainUserId, changeType: 'password', userPwd: this.prePassword, userNextPwd: this.confirmPassword}

      this.$store.dispatch('apiUserSelfPwTran', obj).then(() => {
        if(this.loginPwTran.code === 'SUCCESS') {
          this.passwordDialog = false
          this.clickLogin()
        } else if (this.loginPwTran.code === "CUR_PW_ERROR"){ // 기존 비밀번호가 안 맞을 때
          alert(this.loginPwTran.message)
        }else {
          alert(this.loginPwTran.message)
        }
      }).catch((error) => {
        alert('ErrorCode = ' + error.response.status + ' / ' + error.message + '\n시스템에 이상이 있습니다. 다시 시도해 주세요.')
      }).finally(() => {
        setTimeout(() => {
          alert('패스워드가 변경되었습니다.')
          this.$loadingHide()
        }, 1000);
      })
    },
    logout() {
      const deleteRowConfirm = confirm('로그아웃 하시겠습니까?')
      if (deleteRowConfirm === true) {
        sessionStorage.clear()
        if (this.ownerKey === 'A08462') {
          this.$router.replace('/jnj') 
        } else {
          this.$router.replace('/')
        }
      }
    },
    setSessionData(){
      var info = JSON.parse(sessionStorage.getItem('userInfo'))
      var selectOwner = sessionStorage.getItem('selectOwner')

      for(var i=0; i<info.length; i++){
          if(info[i].ownerKey == selectOwner){
            this.userId = info[i].userId
            this.userName = info[i].userNm
            this.userGroup = info[i].groupNm
            this.userTel = info[i].userTel
            this.userEmail = info[i].userEmail
            this.mainUserName = info[i].userNm
            this.mainUserId = info[i].userId

            this.ownerKey = info[i].ownerKey
            this.agentCd = info[i].agentCd

            break
          }
      }
    },
    ownerSelectEvent (event){
      //console.log(event)
      this.ownerKey = event.value

      sessionStorage.setItem('selectOwner', this.ownerKey)

      this.customerVal = event

      if (sessionStorage.getItem('userInfo') === null) {
        alert('세션이 만료되어 로그인 페이지로 이동합니다.')
        sessionStorage.clear()
        this.$router.replace('/')
        return
      }else{
        this.tabFlag = true
        // this.setRouterInit()
        this.callTotalInfo()
      }
      // const obj =  {'userId': this.mainUserId, 'customVal': this.customerVal.value}
      // console.log(obj)
      //this.$tabs.reset('main')
    }
  },
  mounted() { 
    this.setSessionData()
    this.getUserMenuSetting()
  },
  
  computed: {
    ...mapGetters({
      // userInfo: 'getUserLogin',
      userTranObj: 'getUserInfoTran',
      userSelfPwTran: 'getUserSelfPwTran',
      userMenu: 'getUserMenu',
      userTranRtn: 'getUserTranRtn',
      loginPwTran: 'getUserSelfPwTran',
      totalInfoObj: 'getTotalData',
      codeInfoObj: 'getCodeData',
      custInfoObj: 'getCustMstData',
      ordCustCodeObj: 'getOrdCodeData'
    })
  },
}
</script>
