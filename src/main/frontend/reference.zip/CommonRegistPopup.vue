<style scoped lang="scss">
    .col-md-12{
      padding:12px 0;
    }
    .col-12{
      padding:12px 0;
    }
  .regist-popup{
    >.ui-row{
      padding:0;
      margin:0;
    }
    .ui-col{
      padding:12px 0;
    }
    
  }
</style>
<template>
  <div class="regist-popup">
    <v-row class="ui-row">
      <v-col
        cols="12"
        md="6"
        class="ui-col"
      >
        <label class="default-tit input-tit text-center" for="select-name">
            제품군
          </label>
          <multiselect
            id="select-name"
            v-model="itemVal"
            :options="itemOption"
            :multiple="false"
            selectLabel="추가"
            deselectLabel="선택"
            placeholder="제품군"
            :searchable="true"
            :allow-empty="false"
            @input="selectItemTypeAfter"
            class="default-v-select text-ellip"
            track-by="name"
            label="name"><span slot="noResult">제품군</span></multiselect>
      </v-col>
      <v-col
          cols="12"
          md="6"
          class="ui-col"
      >
        <label class="default-tit input-tit text-center" for="item-code">
            제품코드
          </label>
          <input
          type="text"
          id="item-code"
          class="default-input client-input right"
          placeholder="제품코드"
          v-model="registCdInput"
          />
      </v-col>
      <v-col
        cols="12"
        md="6"
        class="ui-col"
      >
        <label class="default-tit input-tit text-center" for="medium-name">
          중분류
          </label>
          <multiselect
            id="medium-name"
            v-model="mediumVal"
            :options="mediumOption"
            :multiple="false"
            selectLabel="추가"
            deselectLabel="선택"
            placeholder="중분류"
            class="default-v-select text-ellip"
            :searchable="true"
            :allow-empty="false"
            @input="selectItemmediumVal"
            track-by="name"
            label="name"><span slot="noResult">중분류</span></multiselect>
      </v-col>
      <v-col
          cols="12"
          md="6"
          class="ui-col"
      >
        <label class="default-tit input-tit text-center" for="item-name">
            제품명/별칭
          </label>
          <input
          type="text"
          id="item-name"
          class="default-input client-input right"
          placeholder="제품명/별칭"
          v-model="registNmInput"
          />
      </v-col>
      <v-col
        cols="12"
        md="6"
        class="ui-col"
      >
        <label class="default-tit input-tit text-center" for="small-name">
          소분류
          </label>
          <multiselect
            id="small-name"
            v-model="smallVal"
            :options="smallOption"
            :multiple="false"
            selectLabel="추가"
            deselectLabel="선택"
            placeholder="소분류"
            class="default-v-select text-ellip"
            :searchable="true"
            :allow-empty="false"
            track-by="name"
            label="name"><span slot="noResult">소분류</span></multiselect>
      </v-col>
      <v-col
        cols="12"
        md="6"
        class="ui-col"
      >
        <label class="default-tit input-tit text-center" for="contract-status">
            계약여부
            </label>
            <multiselect
              id="contract-status"
              v-model="contractVal"
              :options="contractOption"
              :multiple="false"
              selectLabel="추가"
              deselectLabel="선택"
              placeholder="계약여부"
              class="default-v-select text-ellip"
              track-by="name"
              :searchable="true"
              :allow-empty="false"
              label="name"><span slot="noResult">계약여부</span></multiselect>
      </v-col>
      <v-col
        cols="12"
        md="12"
        class="ui-col"
      >
          <div class="data-control">
            <button type="button" class="search-btn" @click="addItems()" style="margin-left:0">
              <svg xmlns="http://www.w3.org/2000/svg" width="18px" height="18px" fill="#ffffff" viewBox="0 0 24 24"><path d="M12.35 20H10V17H12.09C12.21 16.28 12.46 15.61 12.81 15H10V12H14V13.54C14.58 13 15.25 12.61 16 12.35V12H20V12.35C20.75 12.61 21.42 13 22 13.54V5C22 3.9 21.1 3 20 3H4C2.9 3 2 3.9 2 5V20C2 21.1 2.9 22 4 22H13.54C13 21.42 12.61 20.75 12.35 20M16 7H20V10H16V7M10 7H14V10H10V7M8 20H4V17H8V20M8 15H4V12H8V15M8 10H4V7H8V10M17 14H19V17H22V19H19V22H17V19H14V17H17V14" /></svg>
              제품추가
            </button>
            <button type="button" class="search-btn" @click="searchRegistInfo()">
              <svg xmlns="http://www.w3.org/2000/svg" height="18px" viewBox="0 0 24 24" width="18px" fill="#ffffff"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/></svg>
                검색
            </button>
          </div>
      </v-col>
      <v-col
          cols="12"
          md="12"
          class="ui-col"
      >
          <div id="regist-pop-modal" class="real-grid"></div>  
      </v-col>
    </v-row>
  </div>
</template>

<script>
import { GridView, LocalDataProvider } from 'realgrid'
import { registFields, registColumns } from '../views/gridData/CommonRegistPopup.js'
import { mapGetters } from 'vuex'

let gridView = GridView
let localDataProvider = LocalDataProvider

export default {
  name: 'CommonRegistPopup',
  props : {
    selectRegistEvent : Function,
    ordPropObj: Object
  },
  data() {
    return {
      registList: [],
      registInput: '',
      registNmInput: '',
      registCdInput: '',
      itemOption: [
        {
          name: '전체',
          value: ''
        }
      ],
      itemVal: '',
      mediumVal: [],
      mediumOption: [
        {
          name: '전체',
          value: ''
        }
      ],
      contractVal: '',
      contractOption: [
        // {
        //   name: '전체',
        //   value: ''
        // },
        // {
        //   name: '아니오',
        //   value: 'N'
        // }
        {
          name: '예',
          value: 'Y'
        }
      ], 
      smallVal: '',
      smallOption: [
        {
          name: '전체',
          value: ''
        }
      ],
      groupItems:[]
    }
  },
  methods: {
    getRegistPop() {
        this.registInput = ''
        this.registList = []
        this.contractVal = this.contractOption[0]
        this.itemVal = this.itemOption[0]
        this.smallVal = this.smallOption[0]
        this.mediumVal = this.mediumOption[0]

        this.registCdInput = ''
        this.registNmInput = ''

        this.$loading.show({delay:0})
        this.$store.dispatch('apiOrdItemInfo', this.ordPropObj).then(() => {
          
          if(this.registPopObj.code === 'SUCCESS') {
            //console.log(this.getOrdItemInfo)
            this.registList = this.registPopObj.itemInfo
            // localDataProvider.setRows(this.registList)
            this.getItemMinSetting()
            this.searchRegistInfo()
          } else {
            this.$swal({
              title: this.registPopObj.message
            })
          }
        }).catch((error) => {
          // console.log(error)
          this.$swal({
            title: error
          })
        }).finally(() => {
          setTimeout(() => {
            this.$loadingHide()
          }, 300);
        })
    },
    getItemMinSetting(){
      var array = this.registPopObj.itemInfo
      // console.log('getItemMinSetting')
      // nickName group 치고 Key만 뽑아서 item 제품군 나옴
      this.groupItems = this.groupBy(array, 'nickNm')
      var arr = Object.keys(this.groupItems)
      
      this.itemOption= [
        {
          name: '전체',
          value: ''
        }
      ]

      // console.log(this.groupItems)

      for(var i=0; i<arr.length; i++){
        var item = {'name':arr[i], 'value':arr[i]}
        this.itemOption.push(item)
      }

      
    },
    selectItemTypeAfter(){
      this.smallOption= [
        {
          name: '전체',
          value: ''
        }
      ]

      this.mediumOption = [
        {
          name: '전체',
          value: ''
        }
      ]
      
      this.smallVal = this.smallOption[0]
      this.mediumVal = this.mediumOption[0]
      
      var array = Object.entries(this.groupItems)
      //console.log(Object.entries(array))
      // this.registList = array.filter((e) => e.nickNm === this.itemVal.value)
      
      var arr = array.filter((e) => e[0].indexOf(this.itemVal.value) !== -1)
      arr = arr[0][1]
      //console.log(arr)

      var tmpGroup = this.groupBy(arr, 'ua1')
      var arrKey = Object.keys(tmpGroup)

      for(var i=0; i<arrKey.length; i++){
        if(arrKey[i] !== 'null'){
          var item = {'name':arrKey[i], 'value':arrKey[i]}
          this.mediumOption.push(item)
        }
      }
      
      //console.log(this.mediumOption)

    },
    selectItemmediumVal(){
      this.smallOption= [
        {
          name: '전체',
          value: ''
        }
      ]

      this.smallVal = this.smallOption[0]

      var array = Object.entries(this.groupItems)
      // console.log(Object.entries(array))
      // this.registList = array.filter((e) => e.nickNm === this.itemVal.value)
      
      var arr = array.filter((e) => e[0].indexOf(this.itemVal.value) !== -1)
      arr = arr[0][1]

      var tmpUa1Arr = this.groupBy(arr, 'ua1')
      tmpUa1Arr = Object.entries(tmpUa1Arr)
      tmpUa1Arr = tmpUa1Arr[0][1]
      
      var tmpGroup = this.groupBy(tmpUa1Arr, 'ua2')
      var arrKey = Object.keys(tmpGroup).sort()
      
      // console.log(arrKey)
    
      for(var i=0; i<arrKey.length; i++){
        if(arrKey[i] !== 'null'){
          var item = {'name':arrKey[i], 'value':arrKey[i]}
          this.smallOption.push(item)

        }
      }
      

    },
    searchRegistInfo() {
        //console.log(this.registList)
        
        var tmpArr = []
        for (var i=0; i<this.registList.length; i++) {
            // console.log('registCd ====== ' + this.registList[i].registCd)
            // console.log('registCd ====== ' + this.registList[i].registCd.indexOf(this.registInput))
            

            if(this.registList[i].nickNm !== null && this.registList[i].nickNm !== undefined){
              if(this.registList[i].nickNm.indexOf(this.itemVal.value) === -1){
                continue
              } 
            }

            if(this.registList[i].ua1 !== null && this.registList[i].ua1 !== undefined){
              if(this.registList[i].ua1.indexOf(this.mediumVal.value) === -1){
                continue
              } 
            }

            if(this.registList[i].ua2 !== null && this.registList[i].ua2 !== undefined){
              if(this.registList[i].ua2.indexOf(this.smallVal.value) === -1){
                continue
              } 
            }

            if(this.registList[i].itemCd !== null && this.registList[i].itemCd !== undefined){
              if((this.registList[i].itemCd.toUpperCase()).indexOf(this.registCdInput.toUpperCase()) === -1){
                continue
              } 
            }

            if(this.registList[i].itemNm !== null && this.registList[i].itemNm !== undefined){
              if(((this.registList[i].itemNm.toUpperCase()).indexOf(this.registNmInput.toUpperCase()) === -1) && ((this.registList[i].nickNm.toUpperCase()).indexOf(this.registNmInput.toUpperCase()) === -1))
              {
                continue
              } 
            }

            if(this.registList[i].contractYn !== null && this.registList[i].contractYn !== undefined){
              if(this.registList[i].contractYn.indexOf(this.contractVal.value) === -1){
                continue
              } 
            }

            
            tmpArr.push(this.registList[i])
            

        } 
        // console.log(tmpArr)
        localDataProvider.setRows(tmpArr)
        gridView.refresh()
        
    },
    groupBy(data, key) {
      return data.reduce(function (carry, el) {
        var group = el[key]

        if (carry[group] === undefined) {
            carry[group] = []
        }

        carry[group].push(el)
        return carry
      },{})
    },
    addItems(){
      var items = gridView.getCheckedRows()
      var itemArray = []
      
      if(items.length === 0){
        this.$swal({
          title: '선택 된 데이터가 없습니다.'
        })
        return
      }
      // console.log('items = ' + items)
      for(var i=0; i<items.length; i++){
        var row = localDataProvider.getJsonRow(items[i])        
        itemArray.push(row)
      }
      // console.log(itemArray)
      this.$emit('selectRegistEvent', itemArray)
    },
    rowStyle(grid, item){
      if (localDataProvider.getValue(item.dataRow, 'contractYn') === 'N') {
        return {
          styleName: 'use-enabled-column'
        }
      }
    }
  },
  mounted() {
    // this.startOZViewer()

    localDataProvider = new LocalDataProvider(false)
    gridView = new GridView('regist-pop-modal')
    gridView.setDataSource(localDataProvider)
    gridView.setCheckBar({
      visible: true,
      showAll: false
    })
    gridView.setStateBar({
      visible: false
    })
    gridView.setFooters({
      visible: false
    })
    localDataProvider.setFields(registFields)
    gridView.setColumns(registColumns)


    gridView.setColumnProperty("itemCd", "autoFilter", true)
    gridView.setColumnProperty("itemNm", "autoFilter", true)
    gridView.displayOptions.fitStyle = "even"
    gridView.displayOptions.selectionStyle = "singleRow"

    gridView.columnByName('avaYn').displayCallback = function (grid, index) {
      let avaQty = grid.getValue(index.dataRow,'avaQty')
      
      if(avaQty > 0){
        return 'Y'
      }else{
        return 'N'
      } 
    }

    /*gridView.setRowStyleCallback = function(grid, item, fixed){
      console.log('setRowStyleCallback')
      console.log(grid)
      console.log(item)
      console.log(fixed)
    }*/
    gridView.setRowStyleCallback(this.rowStyle)

    gridView.onCellClicked = function (grid, clickData) {
      if(clickData.cellType === 'check'){
        var idx = clickData.dataRow
        var obj = localDataProvider.getJsonRow(idx)

        // console.log(obj)
        if(obj.contractYn === 'N'){
          this.$swal({
            title: '선택하신 제품은 계약된 제품이 아닙니다. 계약 후 주문해주세요.'
          })
          gridView.checkItem(idx, false)
        }

      }
      
    }
    
    this.getRegistPop()
  },
  computed: {
    ...mapGetters({
      registPopObj: 'getOrdItemInfo'
    })
  },
}
</script>